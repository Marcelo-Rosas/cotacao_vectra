
CREATE TABLE IF NOT EXISTS products (
  id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  owner_user_id TEXT NOT NULL,
  sku          TEXT NOT NULL,
  name         TEXT NOT NULL,
  ncm          TEXT,
  unit         TEXT,
  price_cents  INTEGER DEFAULT 0,
  weight_kg    REAL,
  length_cm    REAL,
  width_cm     REAL,
  height_cm    REAL,
  active       INTEGER NOT NULL DEFAULT 1,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_products_owner_sku ON products (owner_user_id, sku);
CREATE INDEX IF NOT EXISTS idx_products_owner_active ON products (owner_user_id, active);
CREATE INDEX IF NOT EXISTS idx_products_owner_name ON products (owner_user_id, name);

CREATE TRIGGER IF NOT EXISTS trg_products_updated_at
AFTER UPDATE ON products
FOR EACH ROW
BEGIN
  UPDATE products SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;
