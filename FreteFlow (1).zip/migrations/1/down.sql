
DROP INDEX idx_cashback_embarcador;
DROP INDEX idx_cotacao_itens_cotacao;
DROP INDEX idx_cotacoes_embarcador;
DROP INDEX idx_produtos_embarcador;
DROP INDEX idx_embarcadores_user_id;
DROP TABLE cashback;
DROP TABLE cotacao_itens;
DROP TABLE cotacoes;
DROP TABLE regioes_cashback;
DROP TABLE produtos;
DROP TABLE embarcadores;
