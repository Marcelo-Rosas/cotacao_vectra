
DROP INDEX IF EXISTS idx_sessions_expires;
DROP INDEX IF EXISTS idx_sessions_user;
DROP INDEX IF EXISTS idx_usuarios_emb_email;
DROP INDEX IF EXISTS idx_usuarios_admin_email;
DROP TABLE IF EXISTS auth_sessions;
DROP TABLE IF EXISTS usuarios_embarcadores;
DROP TABLE IF EXISTS usuarios_admin;
