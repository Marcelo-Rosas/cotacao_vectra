
DROP TRIGGER IF EXISTS trg_products_updated_at;
DROP INDEX IF EXISTS idx_products_owner_name;
DROP INDEX IF EXISTS idx_products_owner_active;
DROP INDEX IF EXISTS idx_products_owner_sku;
DROP TABLE IF EXISTS products;
