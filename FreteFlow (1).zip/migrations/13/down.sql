
-- Remover usuário admin criado
DELETE FROM users WHERE email = 'marcelo.rosas@vectracargo.com.br';
DELETE FROM user_sessions WHERE user_id = 'admin-marcelo-rosas-vectra';
