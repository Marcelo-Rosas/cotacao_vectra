
-- Inserir regiões padrão de cashback se não existirem
INSERT OR IGNORE INTO regioes_cashback (id, nome, estados, percentual_cashback, created_at, updated_at)
VALUES 
(1, 'Sudeste', 'SP,RJ,MG,ES', 0.02, datetime('now'), datetime('now')),
(2, 'Sul', 'RS,SC,PR', 0.025, datetime('now'), datetime('now')),
(3, 'Nordeste', 'BA,PE,CE,AL,SE,RN,PB,PI,MA', 0.03, datetime('now'), datetime('now')),
(4, 'Centro-Oeste', 'GO,MT,MS,DF', 0.025, datetime('now'), datetime('now')),
(5, 'Norte', 'AM,PA,RO,RR,AC,AP,TO', 0.035, datetime('now'), datetime('now'));

-- Adicionar alguns valores de frete de exemplo para cotações existentes (se houver)
UPDATE cotacoes SET valor_frete = 150.00, tipo_frete = 'FOB' WHERE status = 'fechada' AND valor_frete IS NULL;
