
DROP INDEX idx_usuario_embarcador_embarcador;
DROP INDEX idx_usuario_embarcador_user;
DROP INDEX idx_solicitacoes_status;
DROP INDEX idx_sistema_embarcadores_ativo;
DROP TABLE usuario_embarcador;
DROP TABLE solicitacoes_cadastro;
DROP TABLE sistema_embarcadores;
