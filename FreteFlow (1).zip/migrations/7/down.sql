
DELETE FROM regioes_cashback WHERE nome IN ('Sudeste', 'Sul', 'Nordeste', 'Centro-Oeste', 'Norte');
