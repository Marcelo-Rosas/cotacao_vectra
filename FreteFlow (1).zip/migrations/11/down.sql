
DROP INDEX idx_otp_codes_code;
DROP INDEX idx_otp_codes_email;
DROP INDEX idx_user_sessions_token;
DROP INDEX idx_user_sessions_user_id;
DROP INDEX idx_users_email;
DROP TABLE otp_codes;
DROP TABLE user_sessions;
DROP TABLE users;
