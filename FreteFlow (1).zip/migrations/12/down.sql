
-- Remover campos de senha
ALTER TABLE users DROP COLUMN password_set_at;
ALTER TABLE users DROP COLUMN password_hash;
