
-- Tabela para embarcadores do sistema (diferente da tabela embarcadores existente)
CREATE TABLE sistema_embarcadores (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  nome_empresa TEXT NOT NULL,
  cnpj TEXT,
  telefone TEXT,
  email TEXT,
  max_users INTEGER DEFAULT 5,
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para solicitações de cadastro
CREATE TABLE solicitacoes_cadastro (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  nome_empresa TEXT NOT NULL,
  cnpj TEXT NOT NULL,
  contato_nome TEXT NOT NULL,
  contato_email TEXT NOT NULL,
  contato_telefone TEXT,
  observacoes TEXT,
  status TEXT DEFAULT 'PENDENTE',
  respondido_por TEXT,
  motivo_rejeicao TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para vincular usuários a embarcadores do sistema
CREATE TABLE usuario_embarcador (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  user_id TEXT NOT NULL,
  embarcador_id TEXT NOT NULL,
  perfil TEXT DEFAULT 'EMBARCADOR',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id)
);

-- Índices para performance
CREATE INDEX idx_sistema_embarcadores_ativo ON sistema_embarcadores(ativo);
CREATE INDEX idx_solicitacoes_status ON solicitacoes_cadastro(status);
CREATE INDEX idx_usuario_embarcador_user ON usuario_embarcador(user_id);
CREATE INDEX idx_usuario_embarcador_embarcador ON usuario_embarcador(embarcador_id);
