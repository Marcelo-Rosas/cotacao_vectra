
ALTER TABLE cotacoes ADD COLUMN order_position INTEGER DEFAULT 0;

-- Set initial order positions based on created_at
UPDATE cotacoes SET order_position = (
  SELECT COUNT(*) 
  FROM cotacoes c2 
  WHERE c2.embarcador_id = cotacoes.embarcador_id 
  AND c2.status = cotacoes.status 
  AND c2.created_at <= cotacoes.created_at
);

CREATE INDEX idx_cotacoes_order ON cotacoes(embarcador_id, status, order_position);
