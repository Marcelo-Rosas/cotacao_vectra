
ALTER TABLE produtos ADD COLUMN comprimento_m REAL;
ALTER TABLE produtos ADD COLUMN largura_m REAL;
ALTER TABLE produtos ADD COLUMN altura_m REAL;
