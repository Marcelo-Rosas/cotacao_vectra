
-- Add city fields to cotacoes table
ALTER TABLE cotacoes ADD COLUMN cidade_origem TEXT;
ALTER TABLE cotacoes ADD COLUMN cidade_destino TEXT;
ALTER TABLE cotacoes ADD COLUMN uf_origem TEXT;
ALTER TABLE cotacoes ADD COLUMN uf_destino TEXT;

-- Add environment field to distinguish test vs production
ALTER TABLE cotacoes ADD COLUMN ambiente TEXT DEFAULT 'producao';

-- Create table for sequential numbering control per embarcador
CREATE TABLE cotacao_numeracao (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  embarcador_id INTEGER NOT NULL,
  ambiente TEXT NOT NULL DEFAULT 'producao',
  ultimo_numero INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(embarcador_id, ambiente)
);

-- Add client name to cotacoes
ALTER TABLE cotacoes ADD COLUMN nome_cliente TEXT;

-- Add total weight and volume to cotacoes for quick access
ALTER TABLE cotacoes ADD COLUMN peso_total_kg REAL;
ALTER TABLE cotacoes ADD COLUMN volume_total_m3 REAL;
