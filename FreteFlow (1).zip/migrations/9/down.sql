
-- Remove placeholder entries
DELETE FROM usuario_embarcador WHERE user_id = 'VECTRA_ADMIN_PLACEHOLDER';
DELETE FROM sistema_embarcadores WHERE id = 'vectra-cargo-admin';
