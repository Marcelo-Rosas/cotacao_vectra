
-- Tabela de embarcadores (vinculada aos usuários do Mocha Users Service)
CREATE TABLE embarcadores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE,
  razao_social TEXT NOT NULL,
  cnpj TEXT,
  telefone TEXT,
  endereco TEXT,
  cidade TEXT,
  uf TEXT,
  cep TEXT,
  is_ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de produtos por embarcador
CREATE TABLE produtos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  embarcador_id INTEGER NOT NULL,
  codigo TEXT NOT NULL,
  nome TEXT NOT NULL,
  descricao TEXT,
  peso_kg REAL,
  dimensoes_m3 REAL,
  valor_unitario REAL,
  is_ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de regiões para cálculo de cashback
CREATE TABLE regioes_cashback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  estados TEXT NOT NULL, -- lista de UFs separadas por vírgula
  percentual_cashback REAL NOT NULL,
  is_ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de cotações
CREATE TABLE cotacoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  embarcador_id INTEGER NOT NULL,
  numero_cotacao TEXT NOT NULL,
  cep_origem TEXT NOT NULL,
  cep_destino TEXT NOT NULL,
  documento TEXT NOT NULL, -- CNPJ ou CPF
  tipo_documento TEXT NOT NULL, -- 'cnpj' ou 'cpf'
  valor_nf REAL NOT NULL,
  status TEXT DEFAULT 'pendente', -- pendente, aprovada, rejeitada, fechada
  tipo_frete TEXT, -- FOB, CIF
  valor_frete REAL,
  distancia_km REAL,
  prazo_entrega_dias INTEGER,
  observacoes TEXT,
  fechado_em TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de itens da cotação
CREATE TABLE cotacao_itens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cotacao_id INTEGER NOT NULL,
  produto_id INTEGER NOT NULL,
  quantidade INTEGER NOT NULL,
  valor_unitario REAL NOT NULL,
  valor_total REAL NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de cashback gerado
CREATE TABLE cashback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  embarcador_id INTEGER NOT NULL,
  cotacao_id INTEGER NOT NULL,
  regiao_id INTEGER NOT NULL,
  valor_frete REAL NOT NULL,
  percentual_aplicado REAL NOT NULL,
  valor_cashback REAL NOT NULL,
  status TEXT DEFAULT 'pendente', -- pendente, pago
  data_pagamento TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_embarcadores_user_id ON embarcadores(user_id);
CREATE INDEX idx_produtos_embarcador ON produtos(embarcador_id);
CREATE INDEX idx_cotacoes_embarcador ON cotacoes(embarcador_id);
CREATE INDEX idx_cotacao_itens_cotacao ON cotacao_itens(cotacao_id);
CREATE INDEX idx_cashback_embarcador ON cashback(embarcador_id);
