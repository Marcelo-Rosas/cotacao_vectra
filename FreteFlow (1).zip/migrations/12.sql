
-- Adicionar campo de senha na tabela users
ALTER TABLE users ADD COLUMN password_hash TEXT;
ALTER TABLE users ADD COLUMN password_set_at TIMESTAMP;
