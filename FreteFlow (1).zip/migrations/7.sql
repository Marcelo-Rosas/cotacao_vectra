
-- Insert default cashback regions
INSERT INTO regioes_cashback (nome, estados, percentual_cashback, updated_at) VALUES
('Sudeste', 'SP,RJ,MG,ES', 0.02, datetime('now')),
('Sul', 'PR,SC,RS', 0.025, datetime('now')),
('Nordeste', 'BA,PE,CE,PB,RN,AL,SE,PI,MA', 0.03, datetime('now')),
('Centro-Oeste', 'GO,MT,MS,DF', 0.025, datetime('now')),
('Norte', 'AM,PA,AC,RO,RR,AP,TO', 0.035, datetime('now'));
