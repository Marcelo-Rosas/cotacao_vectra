
-- Inserir regiões de cashback padrão
INSERT INTO regioes_cashback (nome, estados, percentual_cashback) VALUES
('Sudeste', 'SP,RJ,MG,ES', 0.02),
('Sul', 'RS,SC,PR', 0.025),
('Nordeste', 'BA,PE,CE,RN,PB,AL,SE,MA,PI', 0.03),
('Norte', 'AM,PA,AC,RO,RR,AP,TO', 0.035),
('Centro-Oeste', 'GO,MT,MS,DF', 0.025);
