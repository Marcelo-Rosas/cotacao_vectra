
DROP TABLE cotacao_numeracao;
ALTER TABLE cotacoes DROP COLUMN volume_total_m3;
ALTER TABLE cotacoes DROP COLUMN peso_total_kg;
ALTER TABLE cotacoes DROP COLUMN nome_cliente;
ALTER TABLE cotacoes DROP COLUMN ambiente;
ALTER TABLE cotacoes DROP COLUMN uf_destino;
ALTER TABLE cotacoes DROP COLUMN uf_origem;
ALTER TABLE cotacoes DROP COLUMN cidade_destino;
ALTER TABLE cotacoes DROP COLUMN cidade_origem;
