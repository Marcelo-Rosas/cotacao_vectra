
DROP INDEX idx_cotacoes_order;
ALTER TABLE cotacoes DROP COLUMN order_position;
