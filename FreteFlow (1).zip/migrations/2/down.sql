
DELETE FROM regioes_cashback WHERE nome IN ('Sudeste', 'Sul', 'Nordeste', 'Norte', 'Centro-Oeste');
