
-- Create an entry to ensure Vectra users are recognized as admins
-- This will help identify Vectra-related admin users
INSERT OR IGNORE INTO usuario_embarcador (user_id, embarcador_id, perfil, updated_at) 
VALUES ('VECTRA_ADMIN_PLACEHOLDER', 'GLOBAL_ADMIN', 'ADMIN', datetime('now'));

-- Create a sistema_embarcadores entry for Vectra Cargo if it doesn't exist
INSERT OR IGNORE INTO sistema_embarcadores (id, nome_empresa, cnpj, telefone, email, max_users, ativo, updated_at)
VALUES ('vectra-cargo-admin', 'VECTRA CARGO', '59.650.913/0001-04', '(21) 97560-2969', 'admin@vectracargo.com', 999, 1, datetime('now'));
