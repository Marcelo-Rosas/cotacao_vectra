
-- Calcular hash SHA-256 da senha "vectra123" manualmente
-- SHA-256 de "vectra123" = a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3

-- Inserir usuário admin se não existir
INSERT OR IGNORE INTO users (
  id, 
  email, 
  name, 
  email_verified, 
  is_active, 
  password_hash, 
  password_set_at,
  created_at
) VALUES (
  'admin-marcelo-rosas-vectra',
  'marcelo.rosas@vectracargo.com.br',
  'Marcelo Rosas - Admin Vectra',
  1,
  1,
  'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3',
  datetime('now'),
  datetime('now')
);

-- Atualizar caso já exista (forçar senha)
UPDATE users SET 
  password_hash = 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3',
  password_set_at = datetime('now'),
  email_verified = 1,
  is_active = 1,
  name = 'Marcelo Rosas - Admin Vectra'
WHERE email = 'marcelo.rosas@vectracargo.com.br';
