
ALTER TABLE produtos DROP COLUMN altura_m;
ALTER TABLE produtos DROP COLUMN largura_m;
ALTER TABLE produtos DROP COLUMN comprimento_m;
