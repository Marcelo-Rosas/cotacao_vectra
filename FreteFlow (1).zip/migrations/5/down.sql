
-- Remover regiões padrão
DELETE FROM regioes_cashback WHERE id IN (1,2,3,4,5);
