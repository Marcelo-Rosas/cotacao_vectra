import z from "zod";

// Schema para embarcador
export const EmbarcadorSchema = z.object({
  id: z.number().optional(),
  user_id: z.string(),
  razao_social: z.string(),
  cnpj: z.string().optional(),
  telefone: z.string().optional(),
  endereco: z.string().optional(),
  cidade: z.string().optional(),
  uf: z.string().optional(),
  cep: z.string().optional(),
  is_ativo: z.boolean().default(true),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type Embarcador = z.infer<typeof EmbarcadorSchema>;

// Schema para produto
export const ProdutoSchema = z.object({
  id: z.number().optional(),
  embarcador_id: z.number(),
  codigo: z.string(),
  nome: z.string(),
  descricao: z.string().optional(),
  peso_kg: z.number().optional(),
  comprimento_m: z.number().optional(),
  largura_m: z.number().optional(),
  altura_m: z.number().optional(),
  dimensoes_m3: z.number().optional(),
  
  is_ativo: z.boolean().default(true),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type Produto = z.infer<typeof ProdutoSchema>;

// Schema para região de cashback
export const RegiaoCashbackSchema = z.object({
  id: z.number().optional(),
  nome: z.string(),
  estados: z.string(),
  percentual_cashback: z.number(),
  is_ativo: z.boolean().default(true),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type RegiaoCashback = z.infer<typeof RegiaoCashbackSchema>;

// Schema para cotação
export const CotacaoSchema = z.object({
  id: z.number().optional(),
  embarcador_id: z.number(),
  numero_cotacao: z.string(),
  cep_origem: z.string(),
  cep_destino: z.string(),
  cidade_origem: z.string().optional(),
  cidade_destino: z.string().optional(),
  uf_origem: z.string().optional(),
  uf_destino: z.string().optional(),
  documento: z.string(),
  tipo_documento: z.enum(['cnpj', 'cpf']),
  nome_cliente: z.string().optional(),
  valor_nf: z.number(),
  peso_total_kg: z.number().optional(),
  volume_total_m3: z.number().optional(),
  status: z.enum(['pendente', 'aprovada', 'rejeitada', 'fechada']).default('pendente'),
  tipo_frete: z.enum(['FOB', 'CIF']).optional(),
  valor_frete: z.number().optional(),
  distancia_km: z.number().optional(),
  prazo_entrega_dias: z.number().optional(),
  observacoes: z.string().optional(),
  fechado_em: z.string().optional(),
  ambiente: z.enum(['producao', 'teste']).default('producao'),
  order_position: z.number().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type Cotacao = z.infer<typeof CotacaoSchema>;

// Schema para item da cotação
export const CotacaoItemSchema = z.object({
  id: z.number().optional(),
  cotacao_id: z.number(),
  produto_id: z.number(),
  quantidade: z.number(),
  valor_unitario: z.number(),
  valor_total: z.number(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type CotacaoItem = z.infer<typeof CotacaoItemSchema>;

// Schema para cashback
export const CashbackSchema = z.object({
  id: z.number().optional(),
  embarcador_id: z.number(),
  cotacao_id: z.number(),
  regiao_id: z.number(),
  valor_frete: z.number(),
  percentual_aplicado: z.number(),
  valor_cashback: z.number(),
  status: z.enum(['pendente', 'pago']).default('pendente'),
  data_pagamento: z.string().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type Cashback = z.infer<typeof CashbackSchema>;

// Schema para criar nova cotação
export const NovaCotacaoSchema = z.object({
  cep_origem: z.string().min(8, 'CEP deve ter 8 dígitos'),
  cep_destino: z.string().min(8, 'CEP deve ter 8 dígitos'),
  cidade_origem: z.string().optional(),
  cidade_destino: z.string().optional(),
  uf_origem: z.string().optional(),
  uf_destino: z.string().optional(),
  documento: z.string().min(11, 'Documento inválido'),
  tipo_documento: z.enum(['cnpj', 'cpf']),
  nome_cliente: z.string().optional(),
  valor_nf: z.number().positive('Valor da NF deve ser positivo'),
  ambiente: z.enum(['producao', 'teste']).default('producao'),
  itens: z.array(z.object({
    produto_id: z.number(),
    quantidade: z.number().positive('Quantidade deve ser positiva'),
  })).min(1, 'Adicione pelo menos um produto'),
  observacoes: z.string().optional(),
});

export type NovaCotacao = z.infer<typeof NovaCotacaoSchema>;

// Schema para usuário do sistema unificado
export interface User {
  id: string;
  email: string;
  name?: string | null;
  company?: string | null;
  role: 'admin' | 'embarcador';
}

// Schema para embarcador do sistema (diferente do embarcador de cotações)
export const SistemaEmbarcadorSchema = z.object({
  id: z.string().optional(),
  nome_empresa: z.string(),
  cnpj: z.string().optional(),
  telefone: z.string().optional(),
  email: z.string().optional(),
  max_users: z.number().default(5),
  ativo: z.boolean().default(true),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type SistemaEmbarcador = z.infer<typeof SistemaEmbarcadorSchema>;

// Schema para solicitação de cadastro
export const SolicitacaoCadastroSchema = z.object({
  id: z.string().optional(),
  nome_empresa: z.string(),
  cnpj: z.string(),
  contato_nome: z.string(),
  contato_email: z.string(),
  contato_telefone: z.string().optional(),
  observacoes: z.string().optional(),
  status: z.enum(['PENDENTE', 'APROVADO', 'REJEITADO']).default('PENDENTE'),
  respondido_por: z.string().optional(),
  motivo_rejeicao: z.string().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type SolicitacaoCadastro = z.infer<typeof SolicitacaoCadastroSchema>;

// Schema para vincular usuário ao embarcador
export const UsuarioEmbarcadorSchema = z.object({
  id: z.string().optional(),
  user_id: z.string(),
  embarcador_id: z.string(),
  perfil: z.enum(['ADMIN', 'EMBARCADOR']).default('EMBARCADOR'),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type UsuarioEmbarcador = z.infer<typeof UsuarioEmbarcadorSchema>;
