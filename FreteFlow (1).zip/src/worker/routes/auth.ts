import { Hono } from "hono";
import { hashPassword, verifyPassword } from "../utils/authCrypto";
import { makeToken, setSessionCookie, clearSessionCookie, getSessionToken } from "../utils/session";

type Bindings = {
  DB: D1Database;
};

export const authRoute = new Hono<{ Bindings: Bindings }>();

// helper
function isVectra(email: string) {
  return /@vectracargo\.com\.br$/i.test(email.trim());
}

async function ensureSchema(db: D1Database) {
  const stmts = [
    db.prepare(`
      CREATE TABLE IF NOT EXISTS usuarios_admin (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        name TEXT,
        password_hash TEXT NOT NULL,
        password_salt TEXT NOT NULL,
        iterations INTEGER NOT NULL,
        role TEXT NOT NULL DEFAULT 'admin',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_login_at TEXT
      )
    `),
    db.prepare(`CREATE INDEX IF NOT EXISTS idx_usuarios_admin_email ON usuarios_admin(email)`),

    db.prepare(`
      CREATE TABLE IF NOT EXISTS usuarios_embarcadores (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        company TEXT,
        name TEXT,
        password_hash TEXT NOT NULL,
        password_salt TEXT NOT NULL,
        iterations INTEGER NOT NULL,
        role TEXT NOT NULL DEFAULT 'embarcador',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_login_at TEXT
      )
    `),
    db.prepare(`CREATE INDEX IF NOT EXISTS idx_usuarios_emb_email ON usuarios_embarcadores(email)`),

    db.prepare(`
      CREATE TABLE IF NOT EXISTS auth_sessions (
        token TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        role TEXT NOT NULL,
        table_name TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at TEXT NOT NULL
      )
    `),
    db.prepare(`CREATE INDEX IF NOT EXISTS idx_sessions_user ON auth_sessions(user_id)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS idx_sessions_expires ON auth_sessions(expires_at)`)
  ];

  await db.batch(stmts);
}

// REGISTER (auto-provisiona por domínio)
authRoute.post("/register", async (c) => {
  await ensureSchema(c.env.DB);
  const { email, password, name, company } = await c.req.json().catch(() => ({}));
  if (!email || !password) return c.json({ success:false, error:"EMAIL_PASSWORD_REQUIRED" }, 400);

  const table = isVectra(email) ? "usuarios_admin" : "usuarios_embarcadores";
  const id = crypto.randomUUID();
  const rec = await hashPassword(password);
  try {
    const st = c.env.DB.prepare(
      `INSERT INTO ${table} (id,email,name,company,password_hash,password_salt,iterations,role)
       VALUES (?1,?2,?3,?4,?5,?6,?7,?8)`
    ).bind(id, email.toLowerCase(), name ?? null, company ?? null, rec.hash, rec.salt, rec.iterations, isVectra(email) ? "admin" : "embarcador");
    await st.run();
  } catch (e: any) {
    if (String(e?.message || "").includes("UNIQUE")) {
      return c.json({ success:false, error:"EMAIL_ALREADY_EXISTS" }, 409);
    }
    throw e;
  }
  return c.json({ success:true, data:{ id, role: isVectra(email) ? "admin" : "embarcador" }});
});

// LOGIN (se não existir, auto-cria na tabela correta)
authRoute.post("/login", async (c) => {
  await ensureSchema(c.env.DB);
  const { email, password, name, company } = await c.req.json().catch(() => ({}));
  if (!email || !password) return c.json({ success:false, error:"EMAIL_PASSWORD_REQUIRED" }, 400);

  const emailLc = email.toLowerCase();
  const tables = ["usuarios_admin", "usuarios_embarcadores"];

  let user: any = null;
  let tableFound = "";
  for (const t of tables) {
    const row = await c.env.DB.prepare(
      `SELECT id, email, name, company, password_hash, password_salt, iterations, role FROM ${t} WHERE email = ?1`
    ).bind(emailLc).first<any>();
    if (row) { user = row; tableFound = t; break; }
  }

  // auto-provisão
  if (!user) {
    const table = isVectra(emailLc) ? "usuarios_admin" : "usuarios_embarcadores";
    const id = crypto.randomUUID();
    const rec = await hashPassword(password);
    await c.env.DB.prepare(
      `INSERT INTO ${table} (id,email,name,company,password_hash,password_salt,iterations,role)
       VALUES (?1,?2,?3,?4,?5,?6,?7,?8)`
    ).bind(id, emailLc, name ?? null, company ?? null, rec.hash, rec.salt, rec.iterations, isVectra(emailLc) ? "admin" : "embarcador").run();

    user = { id, email: emailLc, name: name ?? null, company: company ?? null, password_hash: rec.hash, password_salt: rec.salt, iterations: rec.iterations, role: isVectra(emailLc) ? "admin" : "embarcador" };
    tableFound = table;
  } else {
    const ok = await verifyPassword(password, {
      hash: user.password_hash, salt: user.password_salt, iterations: user.iterations
    });
    if (!ok) return c.json({ success:false, error:"INVALID_CREDENTIALS" }, 401);
  }

  // cria sessão
  const token = makeToken();
  const days = 7;
  const expires = new Date(Date.now() + days*86400*1000).toISOString();

  await c.env.DB.prepare(
    `INSERT INTO auth_sessions (token,user_id,role,table_name,expires_at) VALUES (?1,?2,?3,?4,?5)`
  ).bind(token, user.id, user.role, tableFound, expires).run();

  setSessionCookie(c, token, days);

  // atualiza last_login
  await c.env.DB.prepare(
    `UPDATE ${tableFound} SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?1`
  ).bind(user.id).run();

  return c.json({ success:true, data:{ id: user.id, email: user.email, role: user.role, name: user.name, company: user.company }});
});

authRoute.post("/logout", async (c) => {
  await ensureSchema(c.env.DB);
  const token = getSessionToken(c);
  if (token) {
    await c.env.DB.prepare(`DELETE FROM auth_sessions WHERE token = ?1`).bind(token).run();
    clearSessionCookie(c);
  }
  return c.json({ success:true });
});
