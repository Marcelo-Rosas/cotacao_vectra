import { Hono } from 'hono';
import type { Context } from 'hono';
import { withSessionAuth } from '../middlewares/auth';

type Bindings = {
  DB: D1Database;
};

type Variables = {
  userId: string;
};

export const produtoRoute = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// Todas as rotas de produto exigem auth
produtoRoute.use('*', withSessionAuth);

// Helpers
function ok<T>(c: Context, data: T, status = 200) {
  return c.json({ success: true, data }, status as any);
}
function fail(c: Context, error: string, status = 400) {
  return c.json({ success: false, error }, status as any);
}

// LISTAR com paginação e busca
// GET /api/produtos?search=&page=1&pageSize=20&active=1
produtoRoute.get('/', async (c) => {
  const userId = c.get('userId');
  const url = new URL(c.req.url);
  const search = (url.searchParams.get('search') ?? '').trim();
  const page = Math.max(1, Number(url.searchParams.get('page') ?? 1));
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get('pageSize') ?? 20)));
  const activeParam = url.searchParams.get('active');
  const activeFilter = activeParam == null ? null : Number(activeParam) ? 1 : 0;

  let where = 'owner_user_id = ?';
  const binds: any[] = [userId];

  if (activeFilter !== null) {
    where += ' AND active = ?';
    binds.push(activeFilter);
  }
  if (search) {
    where += ' AND (sku LIKE ? OR name LIKE ?)';
    binds.push(`%${search}%`, `%${search}%`);
  }

  const offset = (page - 1) * pageSize;

  const totalRow = await c.env.DB
    .prepare(`SELECT COUNT(*) as total FROM products WHERE ${where}`)
    .bind(...binds)
    .first<{ total: number }>();
  const total = totalRow?.total ?? 0;

  const rows = await c.env.DB
    .prepare(
      `SELECT *
         FROM products
        WHERE ${where}
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?`
    )
    .bind(...binds, pageSize, offset)
    .all();

  return ok(c, { items: rows.results ?? [], page, pageSize, total });
});

// CRIAR
// POST /api/produtos
// body: { sku, name, ncm?, unit?, price_cents?, weight_kg?, length_cm?, width_cm?, height_cm?, active? }
produtoRoute.post('/', async (c) => {
  const userId = c.get('userId');
  const body = await c.req.json<any>().catch(() => ({}));

  const sku = String(body?.sku ?? '').trim();
  const name = String(body?.name ?? '').trim();
  if (!sku || !name) return fail(c, 'SKU e nome são obrigatórios', 422);

  const id = crypto.randomUUID();
  const data = {
    id,
    owner_user_id: userId,
    sku,
    name,
    ncm: body?.ncm ?? null,
    unit: body?.unit ?? null,
    price_cents: Number.isFinite(body?.price_cents) ? Number(body.price_cents) : 0,
    weight_kg: body?.weight_kg != null ? Number(body.weight_kg) : null,
    length_cm: body?.length_cm != null ? Number(body.length_cm) : null,
    width_cm: body?.width_cm != null ? Number(body.width_cm) : null,
    height_cm: body?.height_cm != null ? Number(body.height_cm) : null,
    active: body?.active === 0 ? 0 : 1,
  };

  try {
    await c.env.DB
      .prepare(
        `INSERT INTO products
         (id, owner_user_id, sku, name, ncm, unit, price_cents, weight_kg, length_cm, width_cm, height_cm, active)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(
        data.id,
        data.owner_user_id,
        data.sku,
        data.name,
        data.ncm,
        data.unit,
        data.price_cents,
        data.weight_kg,
        data.length_cm,
        data.width_cm,
        data.height_cm,
        data.active
      )
      .run();
  } catch (e: any) {
    const msg = String(e?.message ?? e);
    if (msg.includes('UNIQUE') || msg.includes('unique')) {
      return fail(c, 'SKU já existe para este usuário', 409);
    }
    return fail(c, 'Erro ao criar produto', 500);
  }

  const created = await c.env.DB
    .prepare('SELECT * FROM products WHERE id = ?')
    .bind(id)
    .first();
  return ok(c, created, 201);
});

// DETALHE
// GET /api/produtos/:id
produtoRoute.get('/:id', async (c) => {
  const userId = c.get('userId');
  const id = c.req.param('id');

  const row = await c.env.DB
    .prepare('SELECT * FROM products WHERE id = ? AND owner_user_id = ?')
    .bind(id, userId)
    .first();

  if (!row) return fail(c, 'Produto não encontrado', 404);
  return ok(c, row);
});

// ATUALIZAR (PUT total ou PATCH parcial - aqui aceitamos parcial)
// PUT /api/produtos/:id
produtoRoute.put('/:id', async (c) => {
  const userId = c.get('userId');
  const id = c.req.param('id');
  const patch = await c.req.json<any>().catch(() => ({}));

  const existing = await c.env.DB
    .prepare('SELECT * FROM products WHERE id = ? AND owner_user_id = ?')
    .bind(id, userId)
    .first<any>();
  if (!existing) return fail(c, 'Produto não encontrado', 404);

  // Merge simples (mantém valores existentes se não vier no body)
  const merged = {
    ...existing,
    sku: patch?.sku != null ? String(patch.sku).trim() : existing.sku,
    name: patch?.name != null ? String(patch.name).trim() : existing.name,
    ncm: patch?.ncm ?? existing.ncm,
    unit: patch?.unit ?? existing.unit,
    price_cents:
      patch?.price_cents != null ? Number(patch.price_cents) : existing.price_cents,
    weight_kg: patch?.weight_kg != null ? Number(patch.weight_kg) : existing.weight_kg,
    length_cm: patch?.length_cm != null ? Number(patch.length_cm) : existing.length_cm,
    width_cm: patch?.width_cm != null ? Number(patch.width_cm) : existing.width_cm,
    height_cm: patch?.height_cm != null ? Number(patch.height_cm) : existing.height_cm,
    active: patch?.active != null ? (patch.active ? 1 : 0) : existing.active,
  };

  try {
    await c.env.DB
      .prepare(
        `UPDATE products
           SET sku = ?, name = ?, ncm = ?, unit = ?, price_cents = ?,
               weight_kg = ?, length_cm = ?, width_cm = ?, height_cm = ?, active = ?
         WHERE id = ? AND owner_user_id = ?`
      )
      .bind(
        merged.sku,
        merged.name,
        merged.ncm,
        merged.unit,
        merged.price_cents,
        merged.weight_kg,
        merged.length_cm,
        merged.width_cm,
        merged.height_cm,
        merged.active,
        id,
        userId
      )
      .run();
  } catch (e: any) {
    const msg = String(e?.message ?? e);
    if (msg.includes('UNIQUE') || msg.includes('unique')) {
      return fail(c, 'SKU já existe para este usuário', 409);
    }
    return fail(c, 'Erro ao atualizar produto', 500);
  }

  const updated = await c.env.DB
    .prepare('SELECT * FROM products WHERE id = ?')
    .bind(id)
    .first();
  return ok(c, updated);
});

// REMOVER
// DELETE /api/produtos/:id?force=1   -> hard delete (opcional)
// Sem force, faz soft delete (active=0)
produtoRoute.delete('/:id', async (c) => {
  const userId = c.get('userId');
  const id = c.req.param('id');
  const url = new URL(c.req.url);
  const force = url.searchParams.get('force') === '1';

  const exists = await c.env.DB
    .prepare('SELECT id FROM products WHERE id = ? AND owner_user_id = ?')
    .bind(id, userId)
    .first();
  if (!exists) return fail(c, 'Produto não encontrado', 404);

  if (force) {
    await c.env.DB
      .prepare('DELETE FROM products WHERE id = ? AND owner_user_id = ?')
      .bind(id, userId)
      .run();
    return ok(c, { id, deleted: true });
  }

  await c.env.DB
    .prepare('UPDATE products SET active = 0 WHERE id = ? AND owner_user_id = ?')
    .bind(id, userId)
    .run();

  return ok(c, { id, active: 0 });
});
