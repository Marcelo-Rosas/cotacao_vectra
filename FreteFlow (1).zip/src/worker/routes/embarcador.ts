import { Hono } from 'hono';
import { z } from 'zod';
import { zValidator } from '@hono/zod-validator';
import { withSessionAuth } from '../middlewares/auth';
import { ok, fail, success } from '../utils/json';

type Bindings = {
  DB: D1Database;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
};

type Vars = {
  userId: string;
};

const EmbarcadorSchema = z.object({
  razao_social: z.string().min(1, 'Razão social é obrigatória'),
  cnpj: z.string().min(11).max(18).optional().nullable(),
  ie: z.string().optional().nullable(),
  email: z.string().email('E-mail inválido').optional().nullable(),
  telefone: z.string().optional().nullable(),
  cep: z.string().optional().nullable(),
  endereco: z.string().optional().nullable(),
  numero: z.string().optional().nullable(),
  complemento: z.string().optional().nullable(),
  bairro: z.string().optional().nullable(),
  cidade: z.string().optional().nullable(),
  uf: z.string().length(2).optional().nullable(),
});

export const embarcadorRoute = new Hono<{ Bindings: Bindings; Variables: Vars }>();

// ✅ protege toda a sub-árvore da rota
embarcadorRoute.use('*', withSessionAuth);

// GET /api/embarcador -> retorna cadastro do usuário logado (ou null)
embarcadorRoute.get('/', async (c) => {
  const userId = c.get('userId');

  const row = await c.env.DB
    .prepare('SELECT * FROM embarcadores WHERE user_id = ?')
    .bind(userId)
    .first();

  return ok(c, row ?? null);
});

// POST /api/embarcador -> upsert do cadastro
embarcadorRoute.post(
  '/',
  zValidator('json', EmbarcadorSchema),
  async (c) => {
    const userId = c.get('userId');
    const body = await c.req.valid('json');

    // Verifica se já existe um embarcador para este usuário
    const existing = await c.env.DB
      .prepare('SELECT id FROM embarcadores WHERE user_id = ?')
      .bind(userId)
      .first<{ id: number }>();

    if (existing) {
      // Update do embarcador existente
      const sql = `
        UPDATE embarcadores SET
          razao_social = ?,
          cnpj = ?,
          telefone = ?,
          endereco = ?,
          cidade = ?,
          uf = ?,
          cep = ?,
          updated_at = datetime('now')
        WHERE user_id = ?
      `;

      await c.env.DB
        .prepare(sql)
        .bind(
          body.razao_social,
          body.cnpj ?? null,
          body.telefone ?? null,
          body.endereco ?? null,
          body.cidade ?? null,
          body.uf ?? null,
          body.cep ?? null,
          userId
        )
        .run();

      const updated = await c.env.DB
        .prepare('SELECT * FROM embarcadores WHERE user_id = ?')
        .bind(userId)
        .first();

      return ok(c, updated, 200);
    } else {
      // Insert de novo embarcador
      const sql = `
        INSERT INTO embarcadores (
          user_id, razao_social, cnpj, telefone, endereco, cidade, uf, cep, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      `;

      const result = await c.env.DB
        .prepare(sql)
        .bind(
          userId,
          body.razao_social,
          body.cnpj ?? null,
          body.telefone ?? null,
          body.endereco ?? null,
          body.cidade ?? null,
          body.uf ?? null,
          body.cep ?? null
        )
        .run();

      const created = await c.env.DB
        .prepare('SELECT * FROM embarcadores WHERE id = ?')
        .bind(result.meta.last_row_id)
        .first();

      return ok(c, created, 201);
    }
  }
);

// PUT /api/embarcador/:id -> atualiza embarcador específico (para casos especiais)
embarcadorRoute.put(
  '/:id',
  zValidator('json', EmbarcadorSchema),
  async (c) => {
    const userId = c.get('userId');
    const embarcadorId = c.req.param('id');
    const body = await c.req.valid('json');

    // Verifica se o embarcador pertence ao usuário logado
    const existing = await c.env.DB
      .prepare('SELECT id FROM embarcadores WHERE id = ? AND user_id = ?')
      .bind(embarcadorId, userId)
      .first();

    if (!existing) {
      return fail(c, 404, 'Embarcador não encontrado ou sem permissão');
    }

    const sql = `
      UPDATE embarcadores SET
        razao_social = ?,
        cnpj = ?,
        telefone = ?,
        endereco = ?,
        cidade = ?,
        uf = ?,
        cep = ?,
        updated_at = datetime('now')
      WHERE id = ? AND user_id = ?
    `;

    await c.env.DB
      .prepare(sql)
      .bind(
        body.razao_social,
        body.cnpj ?? null,
        body.telefone ?? null,
        body.endereco ?? null,
        body.cidade ?? null,
        body.uf ?? null,
        body.cep ?? null,
        embarcadorId,
        userId
      )
      .run();

    const updated = await c.env.DB
      .prepare('SELECT * FROM embarcadores WHERE id = ?')
      .bind(embarcadorId)
      .first();

    return ok(c, updated);
  }
);

// DELETE /api/embarcador/:id -> soft delete do embarcador
embarcadorRoute.delete('/:id', async (c) => {
  const userId = c.get('userId');
  const embarcadorId = c.req.param('id');

  // Verifica se o embarcador pertence ao usuário logado
  const existing = await c.env.DB
    .prepare('SELECT id FROM embarcadores WHERE id = ? AND user_id = ?')
    .bind(embarcadorId, userId)
    .first();

  if (!existing) {
    return fail(c, 404, 'Embarcador não encontrado ou sem permissão');
  }

  // Soft delete - marca como inativo
  await c.env.DB
    .prepare('UPDATE embarcadores SET is_ativo = 0, updated_at = datetime(\'now\') WHERE id = ? AND user_id = ?')
    .bind(embarcadorId, userId)
    .run();

  return success(c, 'Embarcador desativado com sucesso');
});

// GET /api/embarcador/validate -> valida se usuário tem embarcador ativo
embarcadorRoute.get('/validate', async (c) => {
  const userId = c.get('userId');

  const embarcador = await c.env.DB
    .prepare('SELECT id, razao_social, is_ativo FROM embarcadores WHERE user_id = ? AND is_ativo = 1')
    .bind(userId)
    .first();

  const isValid = !!embarcador;

  return ok(c, { 
    valid: isValid,
    embarcador: embarcador ?? null
  });
});
