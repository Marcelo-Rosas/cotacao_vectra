import { Hono } from 'hono';
import { fail, ok } from '../utils/json';

type Bindings = {
  DB: D1Database;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
};

export const cepRoute = new Hono<{ Bindings: Bindings }>();

cepRoute.get('/:cep', async (c) => {
  const raw = c.req.param('cep') ?? '';
  const cep = raw.replace(/\D/g, '');

  if (cep.length !== 8) {
    return fail(c, 400, 'CEP inválido');
  }

  // Format CEP for display (12345678 -> 12345-678)
  const formattedCep = cep.replace(/^(\d{5})(\d{3})$/, '$1-$2');

  try {
    // Try BrasilAPI first (more reliable and faster)
    console.log(`[CEP] Trying BrasilAPI for: ${cep}`);
    
    const brasilApiResponse = await fetch(`https://brasilapi.com.br/api/cep/v2/${cep}`, {
      headers: {
        'User-Agent': 'FreteFlow/1.0'
      },
      cf: { cacheTtl: 60 * 60 * 24 }, // cache 24h na edge
    });
    
    if (brasilApiResponse.ok) {
      const brasilData = await brasilApiResponse.json() as any;
      console.log(`[CEP] BrasilAPI success for: ${cep}`);
      
      return ok(c, {
        cep: formattedCep,
        logradouro: brasilData.street || '',
        bairro: brasilData.district || '',
        cidade: brasilData.city || '',
        uf: brasilData.state || '',
        ibge: brasilData.city_ibge || '',
        ddd: brasilData.ddd || '',
        provider: 'brasilapi'
      });
    }
    
    console.log(`[CEP] BrasilAPI failed (${brasilApiResponse.status}), trying ViaCEP...`);
  } catch (error) {
    console.log(`[CEP] BrasilAPI error:`, error);
  }

  try {
    // Fallback to ViaCEP
    console.log(`[CEP] Trying ViaCEP for: ${cep}`);
    
    const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`, {
      headers: {
        'User-Agent': 'FreteFlow/1.0'
      },
      cf: { cacheTtl: 60 * 60 * 24 }, // cache 24h na edge
    });

    if (!res.ok) {
      return fail(c, 502, 'Falha ao consultar CEP');
    }

    const data = await res.json<any>();
    if (data?.erro) {
      return fail(c, 404, 'CEP não encontrado');
    }

    console.log(`[CEP] ViaCEP success for: ${cep}`);

    return ok(c, {
      cep: data.cep || formattedCep,
      logradouro: data.logradouro || '',
      bairro: data.bairro || '',
      cidade: data.localidade || '',
      uf: data.uf || '',
      ibge: data.ibge || '',
      ddd: data.ddd || '',
      provider: 'viacep'
    });
  } catch (error) {
    console.log(`[CEP] ViaCEP error:`, error);
    return fail(c, 502, 'Falha ao consultar CEP');
  }
});

// Health check para o serviço de CEP
cepRoute.get('/health', (c) => {
  return ok(c, { 
    service: 'cep-lookup',
    providers: ['brasilapi', 'viacep'],
    timestamp: new Date().toISOString()
  });
});
