import { Hono } from "hono";
import { getSessionToken } from "../utils/session";

type Bindings = {
  DB: D1Database;
};

export const usersRoute = new Hono<{ Bindings: Bindings }>();

// GET /api/users/me
usersRoute.get("/me", async (c) => {
  const token = getSessionToken(c);
  if (!token) return c.json({ success:false, error:"UNAUTHORIZED" }, 401);

  const sess = await c.env.DB.prepare(
    `SELECT token, user_id, role, table_name, expires_at FROM auth_sessions WHERE token = ?1`
  ).bind(token).first<any>();
  if (!sess) return c.json({ success:false, error:"UNAUTHORIZED" }, 401);

  // expiração
  if (new Date(sess.expires_at).getTime() < Date.now()) {
    await c.env.DB.prepare(`DELETE FROM auth_sessions WHERE token = ?1`).bind(token).run();
    return c.json({ success:false, error:"SESSION_EXPIRED" }, 401);
  }

  const row = await c.env.DB.prepare(
    `SELECT id, email, name, company, role FROM ${sess.table_name} WHERE id = ?1`
  ).bind(sess.user_id).first<any>();
  if (!row) return c.json({ success:false, error:"UNAUTHORIZED" }, 401);

  return c.json({ success:true, data: row });
});
