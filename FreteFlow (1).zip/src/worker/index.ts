import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { cepRoute } from './routes/cep';
import { embarcadorRoute } from './routes/embarcador';
import { produtoRoute } from './routes/produto';
import { authRoute } from './routes/auth';
import { usersRoute } from './routes/users';

type Bindings = {
  DB: D1Database;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
};

const app = new Hono<{ Bindings: Bindings }>();

// Reflete a origem (credenciais + wildcard não combinam)
app.use('*', cors({
  origin: (o) => o ?? '*',
  credentials: true,
}));

app.get('/api/health', (c) => c.json({ success: true, ts: Date.now() }));

// Rotas
app.route('/api/cep', cepRoute);                // público
app.route('/api/auth', authRoute);              // público - autenticação
app.route('/api/users', usersRoute);            // protegido - gestão de usuários
app.route('/api/embarcador', embarcadorRoute);  // protegido (o use() está dentro do módulo)
app.route('/api/produtos', produtoRoute);       // protegido

export default app;
