// Cloudflare Workers: use WebCrypto (PBKDF2 + SHA-256)
export type PasswordRecord = {
  hash: string;
  salt: string;
  iterations: number;
};

export async function hashPassword(plain: string): Promise<PasswordRecord> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iterations = 120_000; // ~120k; ajuste conforme performance do worker
  const key = await deriveKey(plain, salt, iterations);
  const hash = buf2b64(await crypto.subtle.exportKey("raw", key) as ArrayBuffer);
  return { hash, salt: buf2b64(salt), iterations };
}

export async function verifyPassword(plain: string, rec: PasswordRecord): Promise<boolean> {
  const salt = b642buf(rec.salt);
  const key = await deriveKey(plain, salt, rec.iterations);
  const hash = buf2b64(await crypto.subtle.exportKey("raw", key) as ArrayBuffer);
  return timingSafeEqual(hash, rec.hash);
}

async function deriveKey(plain: string, salt: Uint8Array, iterations: number) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw", enc.encode(plain), { name: "PBKDF2" }, false, ["deriveBits", "deriveKey"]
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
    keyMaterial,
    { name: "AES-GCM", length: 256 }, // usamos a key como container de 256 bits
    false,
    ["encrypt", "decrypt"]
  );
}

function buf2b64(buf: ArrayBuffer | Uint8Array) {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let bin = ""; for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

function b642buf(b64: string) {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

function timingSafeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let out = 0; for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}
