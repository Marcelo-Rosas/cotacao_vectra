import { setCookie, getCookie, deleteCookie } from "hono/cookie";

export function makeToken(len = 48) {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  return Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
}

export function setSessionCookie(c: any, token: string, maxDays = 7) {
  const secure = new URL(c.req.url).protocol === "https:";
  const maxAge = maxDays * 86400;
  setCookie(c, "session_token", token, {
    httpOnly: true,
    sameSite: "Lax",
    path: "/",
    secure,
    maxAge
  });
}

export function clearSessionCookie(c: any) {
  deleteCookie(c, "session_token", { path: "/" });
}

export function getSessionToken(c: any) {
  return getCookie(c, "session_token") || null;
}
