import type { Context } from 'hono';

// Helper para respostas de sucesso padronizadas
export function ok<T>(c: Context, data: T, status = 200) {
  return c.json({ success: true, data }, status as any);
}

// Helper para respostas de erro padronizadas
export function fail(c: Context, status = 400, error = 'ERROR', details?: unknown) {
  return c.json({ success: false, error, details }, status as any);
}

// Helper para respostas simples de sucesso
export function success(c: Context, message?: string, status = 200) {
  return c.json({ success: true, message }, status as any);
}

// Helper para paginação
export function paginated<T>(c: Context, items: T[], page: number, pageSize: number, total: number) {
  return c.json({
    success: true,
    data: {
      items,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    },
  });
}

// Helper para garantir Content-Type correto
export function ensureJsonContentType(c: Context) {
  c.header('Content-Type', 'application/json');
}
