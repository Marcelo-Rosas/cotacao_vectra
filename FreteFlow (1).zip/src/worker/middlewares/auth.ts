import type { Context, Next } from 'hono';
import { getCookie } from 'hono/cookie';
import { fail } from '../utils/json';

// Middleware de autenticação baseado em sessão (novo sistema)
export async function withSessionAuth(c: Context, next: Next) {
  try {
    const sessionToken = getCookie(c, 'session_token');
    
    if (!sessionToken) {
      return fail(c, 401, 'UNAUTHORIZED');
    }
    
    // Buscar sessão e usuário
    const session = await c.env.DB
      .prepare(`
        SELECT s.*, u.*
        FROM user_sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.token = ? AND s.expires_at > datetime('now') AND u.is_active = 1
      `)
      .bind(sessionToken)
      .first();
    
    if (!session) {
      return fail(c, 401, 'UNAUTHORIZED');
    }
    
    // Adicionar dados ao contexto
    c.set('userId', session.user_id);
    
    await next();
  } catch (error) {
    console.error('[withSessionAuth] Error:', error);
    return fail(c, 401, 'UNAUTHORIZED');
  }
}

// Valida sessão consultando o Users Service diretamente (fallback/legacy)
export async function withAuth(c: Context, next: Next) {
  const res = await fetch(`${c.env.MOCHA_USERS_SERVICE_API_URL}/api/users/me`, {
    headers: {
      Cookie: c.req.header('Cookie') ?? '',
      'x-api-key': c.env.MOCHA_USERS_SERVICE_API_KEY ?? '',
    },
    cf: { cacheTtl: 0 },
  });

  if (!res.ok) return fail(c, 401, 'UNAUTHORIZED');

  const me = await res.json() as { id?: string };
  if (!me?.id) return fail(c, 401, 'UNAUTHORIZED');

  c.set('userId', me.id);
  await next();
}

// Usa o middleware oficial do pacote do Mocha (preferencial/legacy)
export async function withMochaAuth(c: Context, next: Next) {
  try {
    const { authMiddleware } = await import('@getmocha/users-service/backend');

    // Aplica o middleware oficial e, em seguida, extrai o userId pro contexto
    return authMiddleware(c, async () => {
      const user = c.get('user');
      if (!user?.id) {
        throw new Error('UNAUTHORIZED');
      }

      c.set('userId', user.id);
      await next();
    });
  } catch (err) {
    console.error('[withMochaAuth] error:', err);
    // Em caso de falha de import, cai no fallback simples
    return withAuth(c, next);
  }
}
