import { useState } from "react";
import { useFormContext, useWatch, useFormState } from "react-hook-form";

type CepResponse = {
  cep?: string;
  state?: string;     // UF
  city?: string;
  neighborhood?: string;
  street?: string;
};

function onlyDigits(v: string) { return v.replace(/\D/g, ""); }
function formatCEP(v: string) {
  const d = onlyDigits(v).slice(0, 8);
  if (d.length <= 5) return d;
  return `${d.slice(0, 5)}-${d.slice(5)}`;
}

export default function CepField({
  name = "cep",
  ufName = "uf",
  cidadeName = "cidade",
  bairroName = "bairro",
  logradouroName = "logradouro",
  focusAfter = "numero",       // campo que recebe foco após o autofill
  label = "CEP",
}: {
  name?: string;
  ufName?: string;
  cidadeName?: string;
  bairroName?: string;
  logradouroName?: string;
  focusAfter?: string;
  label?: string;
}) {
  const { register, setValue, setError, clearErrors, trigger, setFocus, control } = useFormContext();
  const { errors } = useFormState({ control });
  const cepValue = useWatch({ control, name }) as string | undefined;
  const [loading, setLoading] = useState(false);

  async function handleLookup(raw: string) {
    const digits = onlyDigits(raw);
    if (digits.length !== 8) return; // evita request curto
    setLoading(true);
    try {
      const res = await fetch(`/api/cep/${digits}`, { credentials: "include" });
      const json = (await res.json()) as { success?: boolean; data?: CepResponse; message?: string };
      if (!res.ok || !json?.data) {
        throw new Error(json?.message || "CEP não encontrado");
      }
      const a = json.data;
      // Preenche campos relacionados
      if (a.state) setValue(ufName, a.state);
      if (a.city) setValue(cidadeName, a.city);
      if (a.neighborhood) setValue(bairroName, a.neighborhood);
      if (a.street) setValue(logradouroName, a.street);
      clearErrors([ufName, cidadeName, bairroName, logradouroName]);
      // dispara validação dos campos preenchidos
      await trigger([ufName, cidadeName, bairroName, logradouroName]);
      // foca no próximo campo
      if (focusAfter) setFocus(focusAfter as any);
    } catch (err: any) {
      setError(name as any, { type: "manual", message: err?.message || "Erro ao consultar CEP" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium">{label}</label>
      <div className="flex gap-2">
        <input
          {...register(name)}
          inputMode="numeric"
          autoComplete="postal-code"
          placeholder="00000-000"
          className="flex-1 rounded-md border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
          value={formatCEP(cepValue || "")}
          onChange={(e) => {
            // formata em tempo real
            const formatted = formatCEP(e.target.value);
            // RHF controla via setValue para manter apenas dígitos como valor "real"
            const digits = onlyDigits(formatted);
            setValue(name, formatted, { shouldValidate: true });
            // dispara lookup automaticamente quando completar 8 dígitos
            if (digits.length === 8) handleLookup(formatted);
          }}
          onBlur={(e) => handleLookup(e.target.value)}
        />
        <button
          type="button"
          onClick={() => handleLookup(cepValue || "")}
          className="rounded-md border px-3 py-2 text-sm disabled:opacity-60"
          disabled={loading || !cepValue || onlyDigits(cepValue).length !== 8}
          title="Buscar CEP"
        >
          {loading ? "Buscando..." : "Buscar"}
        </button>
      </div>
      {errors?.[name as any] && (
        <p className="text-xs text-red-600">{String((errors as any)[name]?.message)}</p>
      )}
    </div>
  );
}
