import FeatureCard from "@/react-app/components/FeatureCard";
import type { IconName } from "@/react-app/components/icons";

export type FeatureItem = {
  title: string;
  desc: string;
  icon: IconName;
  to?: string;
};

export default function FeatureGrid({ items }: { items: FeatureItem[] }) {
  return (
    <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((f) => (
        <FeatureCard key={f.title} {...f} />
      ))}
    </div>
  );
}
