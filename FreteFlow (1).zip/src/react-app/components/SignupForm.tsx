import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/react-app/providers/AuthProvider';
import { Mail, Loader2, ArrowLeft, CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';

interface SignupFormProps {
  onSuccess?: () => void;
  redirectTo?: string;
}

export default function SignupForm({ onSuccess, redirectTo = '/dashboard' }: SignupFormProps) {
  const { sendOTP, verifyOTP } = useAuth();
  const navigate = useNavigate();
  
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [countdown, setCountdown] = useState(0);

  // Enviar código OTP
  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setMessage({ type: 'error', text: 'Email é obrigatório' });
      return;
    }

    setIsLoading(true);
    setMessage(null);

    try {
      const result = await sendOTP(email, name.trim() || undefined);
      
      if (result.success) {
        setMessage({ type: 'success', text: 'Código enviado para seu email!' });
        setStep('code');
        startCountdown();
      } else {
        setMessage({ type: 'error', text: result.error || 'Erro ao enviar código' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erro de conexão' });
    } finally {
      setIsLoading(false);
    }
  };

  // Verificar código OTP e criar conta
  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!code || code.length !== 6) {
      setMessage({ type: 'error', text: 'Código deve ter 6 dígitos' });
      return;
    }

    if (!password || password.length < 6) {
      setMessage({ type: 'error', text: 'Senha deve ter pelo menos 6 caracteres' });
      return;
    }

    if (password !== confirmPassword) {
      setMessage({ type: 'error', text: 'Senhas não coincidem' });
      return;
    }

    setIsLoading(true);
    setMessage(null);

    try {
      const result = await verifyOTP(email, code, password);
      
      if (result.success) {
        setMessage({ type: 'success', text: 'Conta criada com sucesso!' });
        
        // Chamar callback ou navegar
        setTimeout(() => {
          if (onSuccess) {
            onSuccess();
          } else {
            navigate(redirectTo);
          }
        }, 1000);
      } else {
        setMessage({ type: 'error', text: result.error || 'Código inválido' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erro de conexão' });
    } finally {
      setIsLoading(false);
    }
  };

  // Countdown para reenvio
  const startCountdown = () => {
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Reenviar código
  const handleResendCode = async () => {
    if (countdown > 0) return;
    
    setIsLoading(true);
    setMessage(null);

    try {
      const result = await sendOTP(email, name.trim() || undefined);
      
      if (result.success) {
        setMessage({ type: 'success', text: 'Novo código enviado!' });
        startCountdown();
      } else {
        setMessage({ type: 'error', text: result.error || 'Erro ao reenviar código' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erro de conexão' });
    } finally {
      setIsLoading(false);
    }
  };

  // Voltar para tela de email
  const handleBackToEmail = () => {
    setStep('email');
    setCode('');
    setPassword('');
    setConfirmPassword('');
    setMessage(null);
    setCountdown(0);
  };

  return (
    <div className="max-w-md w-full space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl shadow-xl">
            <Mail className="w-8 h-8 text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900">
          {step === 'email' ? 'Criar conta' : 'Verificar código'}
        </h2>
        <p className="text-gray-600 mt-2">
          {step === 'email' 
            ? 'Enviaremos um código de verificação para seu email'
            : `Código enviado para ${email}`
          }
        </p>
      </div>

      {/* Message */}
      {message && (
        <div className={`p-4 rounded-xl flex items-center space-x-3 ${
          message.type === 'success' 
            ? 'bg-green-50 text-green-800 border border-green-200' 
            : 'bg-red-50 text-red-800 border border-red-200'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle className="w-5 h-5" />
          ) : (
            <AlertCircle className="w-5 h-5" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* Formulário Email */}
      {step === 'email' && (
        <form onSubmit={handleSendOTP} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
              Email *
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
              Nome (opcional)
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Seu nome"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading || !email}
            className="w-full flex justify-center items-center py-3 px-4 bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 space-x-3"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Enviando...</span>
              </>
            ) : (
              <>
                <Mail className="w-5 h-5" />
                <span>Enviar código</span>
              </>
            )}
          </button>
        </form>
      )}

      {/* Formulário Código e Senha */}
      {step === 'code' && (
        <div className="space-y-4">
          <button
            onClick={handleBackToEmail}
            className="flex items-center text-orange-600 hover:text-orange-500 font-medium space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar</span>
          </button>

          <form onSubmit={handleVerifyOTP} className="space-y-4">
            <div>
              <label htmlFor="code" className="block text-sm font-medium text-gray-700 mb-2">
                Código de 6 dígitos
              </label>
              <input
                id="code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000"
                maxLength={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent text-center text-2xl font-mono tracking-widest"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Criar senha *
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Pelo menos 6 caracteres"
                  required
                  minLength={6}
                  className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                Confirmar senha *
              </label>
              <div className="relative">
                <input
                  id="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirme sua senha"
                  required
                  className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || code.length !== 6 || !password || !confirmPassword}
              className="w-full flex justify-center items-center py-3 px-4 bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 space-x-3"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Criando conta...</span>
                </>
              ) : (
                <span>Criar conta</span>
              )}
            </button>
          </form>

          {/* Reenviar código */}
          <div className="text-center">
            <button
              onClick={handleResendCode}
              disabled={countdown > 0 || isLoading}
              className="text-orange-600 hover:text-orange-500 font-medium disabled:text-gray-400 disabled:cursor-not-allowed"
            >
              {countdown > 0 
                ? `Reenviar em ${countdown}s`
                : 'Reenviar código'
              }
            </button>
          </div>
        </div>
      )}

      {/* Link para login */}
      <div className="text-center">
        <p className="text-sm text-gray-600">
          Já tem uma conta?{' '}
          <button
            onClick={() => navigate('/login')}
            className="text-blue-600 hover:text-blue-500 font-medium"
          >
            Faça login
          </button>
        </p>
      </div>
    </div>
  );
}
