import { useState } from 'react';
import { 
  DndContext, 
  DragEndEvent, 
  DragOverEvent,
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { 
  Clock, 
  CheckCircle, 
  FileText, 
  XCircle,
  MapPin,
  Calendar,
  Package
} from 'lucide-react';
import type { Cotacao } from '@/shared/types';

interface KanbanBoardProps {
  cotacoes: Cotacao[];
  onUpdateStatus: (cotacaoId: number, newStatus: string) => Promise<void>;
}

interface Column {
  id: string;
  title: string;
  status: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
}

const columns: Column[] = [
  {
    id: 'pendente',
    title: 'Pendente',
    status: 'pendente',
    icon: Clock,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50 border-yellow-200'
  },
  {
    id: 'aprovada',
    title: 'Aprovada',
    status: 'aprovada',
    icon: CheckCircle,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50 border-blue-200'
  },
  {
    id: 'fechada',
    title: 'Fechada',
    status: 'fechada',
    icon: FileText,
    color: 'text-green-600',
    bgColor: 'bg-green-50 border-green-200'
  },
  {
    id: 'rejeitada',
    title: 'Rejeitada',
    status: 'rejeitada',
    icon: XCircle,
    color: 'text-red-600',
    bgColor: 'bg-red-50 border-red-200'
  }
];

interface CotacaoCardProps {
  cotacao: Cotacao;
}

function CotacaoCard({ cotacao }: CotacaoCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({
    id: cotacao.id!,
    data: { cotacao }
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pendente': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'aprovada': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'fechada': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejeitada': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`
        bg-white p-4 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200 cursor-grab
        ${isDragging ? 'opacity-50 shadow-lg scale-105' : ''}
      `}
    >
      <div className="space-y-3">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900 text-sm">{cotacao.numero_cotacao}</h3>
          <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getStatusColor(cotacao.status!)}`}>
            {cotacao.status}
          </span>
        </div>

        {/* Route Info */}
        <div className="space-y-2 text-xs text-gray-600">
          <div className="flex items-center space-x-2">
            <MapPin className="w-3 h-3" />
            <span>{cotacao.cidade_origem || cotacao.cep_origem} → {cotacao.cidade_destino || cotacao.cep_destino}</span>
          </div>
          
          {cotacao.nome_cliente && (
            <div className="flex items-center space-x-2">
              <Package className="w-3 h-3" />
              <span className="truncate">{cotacao.nome_cliente}</span>
            </div>
          )}
        </div>

        {/* Values */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-gray-50 p-2 rounded-lg">
            <div className="text-gray-500">NF</div>
            <div className="font-medium text-gray-900">{formatCurrency(cotacao.valor_nf)}</div>
          </div>
          <div className="bg-gray-50 p-2 rounded-lg">
            <div className="text-gray-500">Frete</div>
            <div className="font-medium text-gray-900">
              {cotacao.valor_frete ? formatCurrency(cotacao.valor_frete) : 'Pendente'}
            </div>
          </div>
        </div>

        {/* Additional Info */}
        {(cotacao.peso_total_kg || cotacao.volume_total_m3) && (
          <div className="grid grid-cols-2 gap-2 text-xs">
            {cotacao.peso_total_kg && (
              <div className="text-gray-600">
                <span className="font-medium">Peso:</span> {cotacao.peso_total_kg.toFixed(1)}kg
              </div>
            )}
            {cotacao.volume_total_m3 && (
              <div className="text-gray-600">
                <span className="font-medium">Vol:</span> {cotacao.volume_total_m3.toFixed(3)}m³
              </div>
            )}
          </div>
        )}

        {/* Date */}
        <div className="flex items-center space-x-2 text-xs text-gray-500 pt-2 border-t border-gray-100">
          <Calendar className="w-3 h-3" />
          <span>{formatDate(cotacao.created_at!)}</span>
        </div>
      </div>
    </div>
  );
}

interface KanbanColumnProps {
  column: Column;
  cotacoes: Cotacao[];
}

function KanbanColumn({ column, cotacoes }: KanbanColumnProps) {
  const Icon = column.icon;
  
  return (
    <div className={`rounded-xl border-2 border-dashed p-4 min-h-[500px] ${column.bgColor}`}>
      {/* Column Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon className={`w-5 h-5 ${column.color}`} />
          <h2 className={`font-semibold ${column.color}`}>{column.title}</h2>
        </div>
        <span className={`px-2 py-1 text-xs font-medium rounded-full bg-white ${column.color}`}>
          {cotacoes.length}
        </span>
      </div>

      {/* Cards */}
      <div className="space-y-3">
        <SortableContext items={cotacoes.map(c => c.id!)} strategy={verticalListSortingStrategy}>
          {cotacoes.map((cotacao) => (
            <CotacaoCard key={cotacao.id} cotacao={cotacao} />
          ))}
        </SortableContext>
      </div>

      {/* Empty State */}
      {cotacoes.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <Icon className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Nenhuma cotação</p>
        </div>
      )}
    </div>
  );
}

export default function KanbanBoard({ cotacoes, onUpdateStatus }: KanbanBoardProps) {
  const [, setActiveId] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  // Group cotacoes by status
  const cotacoesByStatus = columns.reduce((acc, column) => {
    acc[column.status] = cotacoes
      .filter(c => c.status === column.status)
      .sort((a, b) => (a.order_position || 0) - (b.order_position || 0));
    return acc;
  }, {} as Record<string, Cotacao[]>);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(String(event.active.id));
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over) {
      setActiveId(null);
      return;
    }

    const activeId = String(active.id);
    const overId = String(over.id);

    // Find the cotacao being dragged
    const activeCotacao = cotacoes.find(c => String(c.id) === activeId);
    if (!activeCotacao) {
      setActiveId(null);
      return;
    }

    // Determine target status
    let targetStatus: string = activeCotacao.status!;
    let targetCotacao = cotacoes.find(c => String(c.id) === overId);
    
    if (targetCotacao) {
      targetStatus = targetCotacao.status!;
    } else {
      // Check if dropped on column
      const column = columns.find(c => c.id === overId);
      if (column) {
        targetStatus = column.status;
      }
    }

    // Update status if changed
    if (targetStatus !== activeCotacao.status) {
      setIsUpdating(true);
      try {
        await onUpdateStatus(activeCotacao.id!, targetStatus!);
      } catch (error) {
        console.error('Error updating cotacao status:', error);
      } finally {
        setIsUpdating(false);
      }
    }

    setActiveId(null);
  };

  const handleDragOver = (_event: DragOverEvent) => {
    // Handle drag over logic if needed
  };

  return (
    <div className="relative">
      {isUpdating && (
        <div className="absolute inset-0 bg-gray-900 bg-opacity-50 z-50 flex items-center justify-center rounded-xl">
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="text-gray-900">Atualizando cotação...</span>
            </div>
          </div>
        </div>
      )}

      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {columns.map((column) => (
            <SortableContext
              key={column.id}
              items={[column.id, ...cotacoesByStatus[column.status].map(c => c.id!)]}
              strategy={verticalListSortingStrategy}
            >
              <div
                id={column.id}
                className="droppable"
              >
                <KanbanColumn
                  column={column}
                  cotacoes={cotacoesByStatus[column.status]}
                />
              </div>
            </SortableContext>
          ))}
        </div>
      </DndContext>
    </div>
  );
}
