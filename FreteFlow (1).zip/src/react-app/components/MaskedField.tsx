import { forwardRef, useState, useEffect } from 'react';
import { User, Phone, Building, FileText } from 'lucide-react';

export interface MaskedFieldProps {
  name?: string;
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  type: 'cnpj' | 'cpf' | 'telefone' | 'documento';
  tipoDocumento?: 'cnpj' | 'cpf'; // Para when type === 'documento'
  error?: string;
  isInvalid?: boolean;
}

// Máscaras e validações
const masks = {
  cnpj: {
    mask: '00.000.000/0000-00',
    placeholder: '00.000.000/0000-00',
    maxLength: 18,
    icon: Building,
    apply: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers
        .replace(/^(\d{2})(\d)/, '$1.$2')
        .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
        .replace(/\.(\d{3})(\d)/, '.$1/$2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .substring(0, 18);
    },
    validate: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers.length === 14;
    }
  },
  cpf: {
    mask: '000.000.000-00',
    placeholder: '000.000.000-00',
    maxLength: 14,
    icon: User,
    apply: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers
        .replace(/^(\d{3})(\d)/, '$1.$2')
        .replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
        .replace(/\.(\d{3})(\d)/, '.$1-$2')
        .substring(0, 14);
    },
    validate: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers.length === 11;
    }
  },
  telefone: {
    mask: '(00) 00000-0000',
    placeholder: '(00) 00000-0000',
    maxLength: 15,
    icon: Phone,
    apply: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers
        .replace(/^(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2')
        .substring(0, 15);
    },
    validate: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers.length === 10 || numbers.length === 11;
    }
  }
};

const MaskedField = forwardRef<HTMLInputElement, MaskedFieldProps>(({
  name,
  value = '',
  onChange,
  placeholder,
  className = '',
  disabled = false,
  required = false,
  label,
  type,
  tipoDocumento = 'cnpj',
  error,
  isInvalid = false,
  ...props
}, ref) => {
  const [inputValue, setInputValue] = useState(value);

  // Determinar qual máscara usar
  const maskType = type === 'documento' ? tipoDocumento : type;
  const maskConfig = masks[maskType];

  // Sync with external value
  useEffect(() => {
    setInputValue(value);
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value;
    const maskedValue = maskConfig.apply(rawValue);
    
    setInputValue(maskedValue);
    onChange?.(maskedValue);
  };

  const handleBlur = () => {
    // Validate on blur if needed
    const isValid = maskConfig.validate(inputValue);
    if (!isValid && inputValue.length > 0) {
      // Could trigger validation error here
    }
  };

  // Determine error state
  const hasError = Boolean(error) || isInvalid;

  // Get icon
  const Icon = maskConfig.icon;

  // Generate label text
  const getLabelText = () => {
    if (label) return label;
    
    switch (type) {
      case 'cnpj': return 'CNPJ';
      case 'cpf': return 'CPF';
      case 'telefone': return 'Telefone';
      case 'documento': return tipoDocumento === 'cnpj' ? 'CNPJ' : 'CPF';
      default: return '';
    }
  };

  return (
    <div className="space-y-2">
      {getLabelText() && (
        <label className="block text-sm font-medium text-gray-700">
          {getLabelText()}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      <div className="relative">
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
          <Icon className="w-5 h-5" />
        </div>
        
        <input
          ref={ref}
          type="text"
          name={name}
          value={inputValue}
          onChange={handleInputChange}
          onBlur={handleBlur}
          placeholder={placeholder || maskConfig.placeholder}
          disabled={disabled}
          required={required}
          maxLength={maskConfig.maxLength}
          className={`
            w-full pl-10 pr-4 py-3 border rounded-xl transition-all duration-200
            focus:ring-2 focus:border-transparent
            ${hasError
              ? 'border-red-300 focus:ring-red-500 bg-red-50'
              : 'border-gray-300 focus:ring-blue-500'
            }
            ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
            ${className}
          `}
          {...props}
        />
      </div>
      
      {/* Error message */}
      {error && (
        <p className="text-sm text-red-600 flex items-center space-x-1">
          <FileText className="w-4 h-4" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
});

MaskedField.displayName = 'MaskedField';

export default MaskedField;
