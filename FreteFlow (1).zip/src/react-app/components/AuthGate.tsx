import { ReactNode } from "react";
import { useAuth } from "@/react-app/providers/AuthProvider";
import { Navigate } from "react-router-dom";
import { Loader2 } from "lucide-react";

interface AuthGateProps {
  children: ReactNode;
  redirectTo?: string;
}

export default function AuthGate({ children, redirectTo = "/login" }: AuthGateProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="flex items-center space-x-3">
          <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
          <span className="text-gray-600">Carregando...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to={redirectTo} replace />;
  }

  return <>{children}</>;
}
