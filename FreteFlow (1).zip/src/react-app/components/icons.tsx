import type { SVGProps } from "react";

type IconName =
  | "box"
  | "spark"
  | "table"
  | "tenant"
  | "truck"
  | "shield"
  | "coins";

export type { IconName };

export function Icon({
  name,
  className,
  ...rest
}: SVGProps<SVGSVGElement> & { name: IconName }) {
  switch (name) {
    case "box":
      return (
        <svg
          viewBox="0 0 24 24"
          aria-hidden="true"
          className={className}
          {...rest}
        >
          <path
            d="M12 3 3 7.5 12 12l9-4.5L12 3Z"
            fill="currentColor"
            opacity=".35"
          />
          <path
            d="M3 7.5V17l9 4.5V12L3 7.5Zm18 0V17l-9 4.5V12l9-4.5Z"
            fill="currentColor"
          />
        </svg>
      );
    case "spark":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...rest}>
          <path d="M12 2l1.8 5.4L19 9l-5.2 1.6L12 16l-1.8-5.4L5 9l5.2-1.6L12 2Z" fill="currentColor"/>
          <circle cx="18" cy="18" r="3" fill="currentColor" opacity=".35"/>
        </svg>
      );
    case "table":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...rest}>
          <rect x="3" y="4" width="18" height="16" rx="2" fill="currentColor" opacity=".35"/>
          <path d="M3 9h18M8 9v11M16 9v11" stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case "tenant":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...rest}>
          <path d="M4 10h6v10H4zM14 4h6v16h-6z" fill="currentColor" />
          <path d="M4 10l9-6 7 4" stroke="currentColor" strokeWidth="2" fill="none"/>
        </svg>
      );
    case "truck":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...rest}>
          <path d="M3 7h11v8H3zM14 10h4l3 3v2h-7v-5z" fill="currentColor" />
          <circle cx="7" cy="17" r="2" fill="currentColor" />
          <circle cx="17" cy="17" r="2" fill="currentColor" />
        </svg>
      );
    case "shield":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...rest}>
          <path d="M12 3l8 3v5c0 5.5-3.5 8.7-8 10-4.5-1.3-8-4.5-8-10V6l8-3z" fill="currentColor"/>
          <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none"/>
        </svg>
      );
    case "coins":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...rest}>
          <ellipse cx="10" cy="7" rx="6" ry="3" fill="currentColor" />
          <path d="M16 7v4c0 1.7-2.7 3-6 3s-6-1.3-6-3V7" fill="currentColor" opacity=".35"/>
          <ellipse cx="16" cy="14" rx="5" ry="2.5" fill="currentColor" />
        </svg>
      );
    default:
      return null;
  }
}
