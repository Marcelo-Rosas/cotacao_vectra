import { useFormContext } from "react-hook-form";
import { useState } from "react";
import { MapPin, Loader2, CheckCircle, AlertCircle } from "lucide-react";

type Props = {
  name: string;
  label?: string;
  placeholder?: string;
  required?: boolean;
  onAutofill?: (data: any) => void;
};

export default function CepFieldClean({ 
  name, 
  label = "CEP", 
  placeholder = "00000-000",
  required = false,
  onAutofill
}: Props) {
  const {
    register,
    watch,
    setValue,
    trigger,
    formState: { errors },
  } = useFormContext();

  const [isLoading, setIsLoading] = useState(false);
  const [cepError, setCepError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const cepValue = watch(name) || '';
  const error = (errors as any)?.[name]?.message as string | undefined;

  // Máscara de CEP
  const formatCep = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 8);
    if (digits.length <= 5) return digits;
    return `${digits.slice(0, 5)}-${digits.slice(5)}`;
  };

  // Auto-preenchimento via CEP
  const preencherPorCep = async (cep: string) => {
    const cepLimpo = cep.replace(/\D/g, '');
    if (cepLimpo.length !== 8) return;

    setIsLoading(true);
    setCepError(null);
    setSuccess(false);

    try {
      const response = await fetch(`/api/cep/${cepLimpo}`, { credentials: 'include' });
      const result = await response.json();

      if (response.ok && result.success && result.data) {
        // Preencher campos automaticamente
        setValue('uf', result.data.uf || '');
        setValue('cidade', result.data.cidade || '');
        setValue('bairro', result.data.bairro || '');
        setValue('logradouro', result.data.logradouro || '');

        // Trigger validação dos campos preenchidos
        await trigger(['uf', 'cidade', 'bairro', 'logradouro']);

        setSuccess(true);
        setCepError(null);

        // Callback opcional
        onAutofill?.(result.data);

        // Focar no próximo campo (número)
        setTimeout(() => {
          const numeroField = document.querySelector('input[name="numero"]') as HTMLInputElement;
          if (numeroField) numeroField.focus();
        }, 100);
      } else {
        setCepError(result.error || 'CEP não encontrado');
        setSuccess(false);
      }
    } catch (error) {
      setCepError('Erro ao consultar CEP');
      setSuccess(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value;
    const formattedValue = formatCep(rawValue);
    
    setValue(name, formattedValue);
    
    // Reset estados
    setCepError(null);
    setSuccess(false);
    
    // Trigger lookup quando completar 8 dígitos
    const digits = formattedValue.replace(/\D/g, '');
    if (digits.length === 8) {
      preencherPorCep(formattedValue);
    }
  };

  const handleBlur = () => {
    if (cepValue) {
      const formattedValue = formatCep(cepValue);
      setValue(name, formattedValue);
      const digits = formattedValue.replace(/\D/g, '');
      if (digits.length === 8) {
        preencherPorCep(formattedValue);
      }
    }
  };

  const hasError = Boolean(error || cepError);
  const hasSuccess = success && !hasError;

  return (
    <div className="space-y-2">
      {label && (
        <label htmlFor={name} className="block text-sm font-medium text-gray-700">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      <div className="relative">
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
          <MapPin className="w-5 h-5" />
        </div>
        
        <input
          id={name}
          type="text"
          placeholder={placeholder}
          maxLength={9}
          className={`
            w-full pl-10 pr-12 py-3 border rounded-xl transition-all duration-200
            focus:ring-2 focus:border-transparent
            ${hasError
              ? 'border-red-300 focus:ring-red-500 bg-red-50'
              : hasSuccess
              ? 'border-green-300 focus:ring-green-500 bg-green-50'
              : 'border-gray-300 focus:ring-blue-500'
            }
          `}
          {...register(name, { 
            required: required ? `${label} é obrigatório` : false,
            onChange: handleInputChange,
            onBlur: handleBlur
          })}
        />
        
        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
          {isLoading ? (
            <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
          ) : hasSuccess ? (
            <CheckCircle className="w-5 h-5 text-green-600" />
          ) : hasError ? (
            <AlertCircle className="w-5 h-5 text-red-600" />
          ) : null}
        </div>
      </div>
      
      {/* Error message */}
      {(error || cepError) && (
        <p className="text-sm text-red-600 flex items-center space-x-1">
          <AlertCircle className="w-4 h-4" />
          <span>{error || cepError}</span>
        </p>
      )}
    </div>
  );
}
