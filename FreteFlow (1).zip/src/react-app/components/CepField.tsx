import { useEffect, useState } from 'react';
import { Loader2, MapPin, CheckCircle, AlertCircle } from 'lucide-react';
import { useCepAutofill, type CepData } from '@/react-app/hooks/useCepAutofill';

export interface CepFieldMapping {
  cidade?: string;
  estado?: string;
  uf?: string;
  bairro?: string;
  logradouro?: string;
  endereco?: string;
}

export interface CepFieldProps {
  name?: string;
  value?: string;
  onChange?: (value: string) => void;
  onAutofill?: (data: CepData) => void;
  map?: CepFieldMapping;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  
  // React Hook Form integration
  setValue?: (name: string, value: any, options?: any) => void;
  
  // Error states
  error?: string;
  isInvalid?: boolean;
}

export default function CepField({
  name = 'cep',
  value = '',
  onChange,
  onAutofill,
  map = {},
  placeholder = 'Digite o CEP',
  className = '',
  disabled = false,
  required = false,
  label = 'CEP',
  setValue,
  error: externalError,
  isInvalid = false
}: CepFieldProps) {
  const [inputValue, setInputValue] = useState(value);

  const {
    isLoading,
    error: cepError,
    data: cepData,
    lookupCep,
    reset
  } = useCepAutofill({
    onSuccess: (data) => {
      console.log('[CepField] Autofill success:', data);
      
      // Call external onAutofill callback
      onAutofill?.(data);
      
      // Auto-fill mapped fields using React Hook Form setValue
      if (setValue) {
        if (map.cidade) setValue(map.cidade, data.cidade);
        if (map.estado || map.uf) setValue(map.estado || map.uf!, data.uf);
        if (map.bairro) setValue(map.bairro, data.bairro);
        if (map.logradouro || map.endereco) {
          setValue(map.logradouro || map.endereco!, data.logradouro);
        }
      }
    },
    onError: (error) => {
      console.log('[CepField] Autofill error:', error);
    }
  });

  // Sync with external value
  useEffect(() => {
    setInputValue(value);
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value;
    
    // Apply CEP mask (12345-678)
    const numbersOnly = rawValue.replace(/\D/g, '');
    const maskedValue = numbersOnly.replace(/^(\d{5})(\d{1,3})/, '$1-$2');
    
    setInputValue(maskedValue);
    onChange?.(maskedValue);
    
    // Reset previous data when CEP changes
    reset();
    
    // Trigger lookup when we have 8 digits
    if (numbersOnly.length === 8) {
      lookupCep(numbersOnly);
    }
  };

  const handleBlur = () => {
    // Format CEP on blur if it has 8 digits
    const numbersOnly = inputValue.replace(/\D/g, '');
    if (numbersOnly.length === 8) {
      const formatted = numbersOnly.replace(/^(\d{5})(\d{3})/, '$1-$2');
      setInputValue(formatted);
      onChange?.(formatted);
    }
  };

  // Determine error state
  const hasError = Boolean(externalError || cepError) || isInvalid;
  const errorMessage = externalError || cepError;

  // Determine success state
  const hasSuccess = Boolean(cepData && !hasError);

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-gray-700">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      <div className="relative">
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
          <MapPin className="w-5 h-5" />
        </div>
        
        <input
          type="text"
          name={name}
          value={inputValue}
          onChange={handleInputChange}
          onBlur={handleBlur}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          maxLength={9} // 12345-678
          className={`
            w-full pl-10 pr-12 py-3 border rounded-xl transition-all duration-200
            focus:ring-2 focus:border-transparent
            ${hasError
              ? 'border-red-300 focus:ring-red-500 bg-red-50'
              : hasSuccess
              ? 'border-green-300 focus:ring-green-500 bg-green-50'
              : 'border-gray-300 focus:ring-blue-500'
            }
            ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
            ${className}
          `}
        />
        
        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
          {isLoading ? (
            <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
          ) : hasSuccess ? (
            <CheckCircle className="w-5 h-5 text-green-600" />
          ) : hasError ? (
            <AlertCircle className="w-5 h-5 text-red-600" />
          ) : null}
        </div>
      </div>
      
      {/* Error message */}
      {errorMessage && (
        <p className="text-sm text-red-600 flex items-center space-x-1">
          <AlertCircle className="w-4 h-4" />
          <span>{errorMessage}</span>
        </p>
      )}
      
      {/* Success message with provider info */}
      {hasSuccess && cepData && (
        <div className="text-sm text-green-600 space-y-1">
          <p className="flex items-center space-x-1">
            <CheckCircle className="w-4 h-4" />
            <span>
              {cepData.cidade}, {cepData.uf}
              {cepData.bairro && ` - ${cepData.bairro}`}
            </span>
          </p>
          {cepData.logradouro && (
            <p className="text-gray-600 text-xs ml-5">{cepData.logradouro}</p>
          )}
          <p className="text-gray-500 text-xs ml-5">
            Via {cepData.provider === 'brasilapi' ? 'BrasilAPI' : 'ViaCEP'}
          </p>
        </div>
      )}
    </div>
  );
}
