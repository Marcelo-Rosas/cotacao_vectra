import { Icon, IconName } from "@/react-app/components/icons";

type Props = {
  title: string;
  desc: string;
  icon: IconName;
  to?: string; // opcional: vira link
};

export default function FeatureCard({ title, desc, icon, to }: Props) {
  const Container = to ? "a" : "div";
  const containerProps = to
    ? { href: to, className: "no-underline" }
    : ({} as Record<string, unknown>);

  return (
    <Container
      {...containerProps}
      className="block rounded-2xl border border-slate-800/40 bg-slate-900 text-white p-5 shadow-xl transition-transform hover:-translate-y-0.5 hover:shadow-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500"
    >
      <span className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
        <Icon name={icon} className="h-5 w-5" />
      </span>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-1 text-slate-300 text-sm">{desc}</p>
    </Container>
  );
}
