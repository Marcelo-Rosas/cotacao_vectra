import { useFormContext } from "react-hook-form";

type Props = {
  name: string;
  label?: string;
  placeholder?: string;
  type?: string;
  autoComplete?: string;
  inputMode?: React.InputHTMLAttributes<HTMLInputElement>["inputMode"];
  maxLength?: number;
  required?: boolean;
};

export default function TextField({ 
  name, 
  label, 
  placeholder, 
  type = "text",
  autoComplete,
  inputMode,
  maxLength,
  required = false
}: Props) {
  const {
    register,
    formState: { errors },
  } = useFormContext();

  const error = (errors as any)?.[name]?.message as string | undefined;

  return (
    <div className="space-y-2">
      {label && (
        <label htmlFor={name} className="block text-sm font-medium text-gray-700">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      <input
        id={name}
        type={type}
        placeholder={placeholder}
        autoComplete={autoComplete}
        inputMode={inputMode}
        maxLength={maxLength}
        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        {...register(name, { required: required ? `${label || 'Campo'} é obrigatório` : false })}
      />
      {error && (
        <p className="text-sm text-red-600">{error}</p>
      )}
    </div>
  );
}
