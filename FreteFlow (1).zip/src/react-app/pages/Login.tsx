import NewLogin from './NewLogin';

export default function Login() {
  return <NewLogin />;
}
