import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import Layout from '@/react-app/components/Layout';
import { get, post, type APIResponse } from '@/react-app/lib/http';

import { 
  Plus, 
  Search, 
  Package, 
  Edit3, 
  Trash2,
  Loader2,
  AlertCircle,
  CheckCircle,
  Download,
  Upload,
  FileSpreadsheet
} from 'lucide-react';
import * as XLSX from 'xlsx';
import type { Produto } from '@/shared/types';

export default function Produtos() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [showNewProduto, setShowNewProduto] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  
  const [formData, setFormData] = useState({
    codigo: '',
    nome: '',
    descricao: '',
    peso_kg: '',
    comprimento_m: '',
    largura_m: '',
    altura_m: ''
  });

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login');
    }
  }, [user, isLoading, navigate]);

  useEffect(() => {
    if (user) {
      loadProdutos();
    }
  }, [user]);

  const loadProdutos = async () => {
    try {
      setLoadingData(true);
      
      const response = await get<APIResponse<Produto[]>>('/api/produtos');
      setProdutos(response.data || []);
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    } finally {
      setLoadingData(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);

    try {
      // Calculate m3 from dimensions
      let dimensoes_m3;
      if (formData.comprimento_m && formData.largura_m && formData.altura_m) {
        dimensoes_m3 = parseFloat((Number(formData.comprimento_m) * Number(formData.largura_m) * Number(formData.altura_m)).toFixed(4));
      }

      const payload = {
        codigo: formData.codigo,
        nome: formData.nome,
        descricao: formData.descricao || undefined,
        peso_kg: formData.peso_kg ? Number(formData.peso_kg) : undefined,
        comprimento_m: formData.comprimento_m ? Number(formData.comprimento_m) : undefined,
        largura_m: formData.largura_m ? Number(formData.largura_m) : undefined,
        altura_m: formData.altura_m ? Number(formData.altura_m) : undefined,
        dimensoes_m3: dimensoes_m3,
        embarcador_id: 0 // Will be set by backend
      };

      await post<APIResponse>('/api/produtos', payload);
      setMessage({ type: 'success', text: 'Produto criado com sucesso!' });
      setShowNewProduto(false);
      setFormData({
        codigo: '',
        nome: '',
        descricao: '',
        peso_kg: '',
        comprimento_m: '',
        largura_m: '',
        altura_m: ''
      });
      loadProdutos();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao criar produto';
      setMessage({ type: 'error', text: errorMessage });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownloadTemplate = () => {
    const templateData = [
      {
        codigo: 'FW-1019',
        nome: '30-DEGREE BENCH',
        peso_kg: 44.00,
        comprimento_m: 1.32,
        largura_m: 0.75,
        altura_m: 0.38,
        m3: 0.3762
      },
      {
        codigo: 'FW-2019',
        nome: 'ADJUSTABLE BENCH',
        peso_kg: 45.00,
        comprimento_m: 1.32,
        largura_m: 0.75,
        altura_m: 0.38,
        m3: 0.3762
      },
      {
        codigo: 'RS-1040',
        nome: '4-WAY NECK MACHINE',
        peso_kg: 140.00,
        comprimento_m: 1.7,
        largura_m: 1,
        altura_m: 0.4,
        m3: 0.6800
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Produtos');
    
    // Generate Excel file and download
    XLSX.writeFile(workbook, 'template_produtos.xlsx');
  };

  const handleDownloadExisting = () => {
    if (produtos.length === 0) {
      setMessage({ type: 'error', text: 'Não há produtos para exportar' });
      return;
    }

    const exportData = produtos.map(produto => ({
      codigo: produto.codigo || '',
      nome: produto.nome || '',
      peso_kg: produto.peso_kg ? parseFloat(produto.peso_kg.toString()).toFixed(2) : '',
      comprimento_m: produto.comprimento_m || '',
      largura_m: produto.largura_m || '',
      altura_m: produto.altura_m || '',
      m3: produto.dimensoes_m3 ? parseFloat(produto.dimensoes_m3.toString()).toFixed(4) : ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Produtos');
    
    const fileName = 'produtos_' + new Date().toISOString().split('T')[0] + '.xlsx';
    XLSX.writeFile(workbook, fileName);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      setMessage({ type: 'error', text: 'Por favor, selecione um arquivo Excel (.xlsx ou .xls)' });
      return;
    }

    setIsUploading(true);
    setMessage(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      if (jsonData.length === 0) {
        setMessage({ type: 'error', text: 'Arquivo deve conter pelo menos uma linha de dados' });
        return;
      }

      const requiredFields = ['codigo', 'nome'];
      const firstRow = jsonData[0] as any;
      const missingFields = requiredFields.filter(field => !firstRow.hasOwnProperty(field));
      
      if (missingFields.length > 0) {
        setMessage({ type: 'error', text: `Colunas obrigatórias ausentes: ${missingFields.join(', ')}` });
        return;
      }

      const produtos = [];
      for (const row of jsonData) {
        const produto: any = {};
        const rowData = row as any;
        
        // Required fields
        produto.codigo = rowData.codigo?.toString().trim() || '';
        produto.nome = rowData.nome?.toString().trim() || '';
        produto.descricao = rowData.nome?.toString().trim() || '';
        
        // Optional numeric fields
        produto.comprimento_m = rowData.comprimento_m ? parseFloat(rowData.comprimento_m.toString()) : undefined;
        produto.largura_m = rowData.largura_m ? parseFloat(rowData.largura_m.toString()) : undefined;
        produto.altura_m = rowData.altura_m ? parseFloat(rowData.altura_m.toString()) : undefined;
        produto.peso_kg = rowData.peso_kg ? parseFloat(rowData.peso_kg.toString()) : undefined;
        
        // Calculate m3 from dimensions or use provided m3
        if (produto.comprimento_m && produto.largura_m && produto.altura_m) {
          produto.dimensoes_m3 = parseFloat((produto.comprimento_m * produto.largura_m * produto.altura_m).toFixed(4));
        } else if (rowData.m3) {
          produto.dimensoes_m3 = parseFloat(parseFloat(rowData.m3.toString()).toFixed(4));
        }

        if (produto.codigo && produto.nome) {
          produtos.push(produto);
        }
      }

      if (produtos.length === 0) {
        setMessage({ type: 'error', text: 'Nenhum produto válido encontrado no arquivo' });
        return;
      }

      // Upload products
      const result = await post<APIResponse<{ created: number }>>('/api/produtos/upload', { produtos });
      setMessage({ 
        type: 'success', 
        text: `${result.data?.created} produtos importados com sucesso!` 
      });
      setShowUploadModal(false);
      loadProdutos();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao processar arquivo Excel';
      setMessage({ type: 'error', text: errorMessage });
    } finally {
      setIsUploading(false);
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  const filteredProdutos = produtos.filter(produto => 
    produto.codigo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    produto.nome?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  

  if (isLoading || loadingData) {
    return (
      <Layout>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Produtos</h1>
            <p className="text-gray-600 mt-2">Gerencie seu catálogo de produtos</p>
          </div>
          <div className="flex items-center space-x-3">
            {/* Export/Import Buttons */}
            <div className="flex items-center space-x-2">
              <button
                onClick={handleDownloadTemplate}
                className="flex items-center px-3 py-2 text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors space-x-2"
                title="Baixar template CSV"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span className="hidden sm:inline">Template</span>
              </button>
              <button
                onClick={handleDownloadExisting}
                className="flex items-center px-3 py-2 text-green-700 bg-green-100 rounded-xl hover:bg-green-200 transition-colors space-x-2"
                title="Exportar produtos existentes"
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Exportar</span>
              </button>
              <button
                onClick={() => setShowUploadModal(true)}
                className="flex items-center px-3 py-2 text-orange-700 bg-orange-100 rounded-xl hover:bg-orange-200 transition-colors space-x-2"
                title="Importar produtos em massa"
              >
                <Upload className="w-4 h-4" />
                <span className="hidden sm:inline">Importar</span>
              </button>
            </div>
            <button
              onClick={() => setShowNewProduto(true)}
              className="flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 space-x-2"
            >
              <Plus className="w-5 h-5" />
              <span>Novo Produto</span>
            </button>
          </div>
        </div>

        {message && (
          <div className={`p-4 rounded-xl flex items-center space-x-3 ${
            message.type === 'success' 
              ? 'bg-green-50 text-green-800 border border-green-200' 
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}>
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Search */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar por código ou nome do produto..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Products List */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
          {filteredProdutos.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">
                {searchTerm ? 'Nenhum produto encontrado' : 'Nenhum produto cadastrado'}
              </h3>
              <p className="text-gray-600 mb-6">
                {searchTerm 
                  ? 'Tente ajustar o termo de busca'
                  : 'Comece adicionando produtos ao seu catálogo'
                }
              </p>
              {!searchTerm && (
                <button
                  onClick={() => setShowNewProduto(true)}
                  className="px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
                >
                  Adicionar Primeiro Produto
                </button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Código
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Nome
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Peso (kg)
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Comprimento (m)
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Largura (m)
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Altura (m)
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      m³
                    </th>
                    
                    <th className="px-6 py-4 text-right text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredProdutos.map((produto) => (
                    <tr key={produto.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{produto.codigo}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">{produto.nome}</div>
                        {produto.descricao && (
                          <div className="text-sm text-gray-500">{produto.descricao}</div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {produto.peso_kg ? parseFloat(produto.peso_kg.toString()).toFixed(2) : '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {produto.comprimento_m ? `${produto.comprimento_m}` : '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {produto.largura_m ? `${produto.largura_m}` : '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {produto.altura_m ? `${produto.altura_m}` : '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {produto.dimensoes_m3 ? parseFloat(produto.dimensoes_m3.toString()).toFixed(4) : '-'}
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-2">
                          <button className="text-blue-600 hover:text-blue-900 p-2 hover:bg-blue-50 rounded-lg transition-colors">
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button className="text-red-600 hover:text-red-900 p-2 hover:bg-red-50 rounded-lg transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* New Product Modal */}
        {showNewProduto && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-75">
            <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900">Novo Produto</h2>
              </div>
              
              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Código *
                  </label>
                  <input
                    type="text"
                    value={formData.codigo}
                    onChange={(e) => setFormData(prev => ({ ...prev, codigo: e.target.value }))}
                    placeholder="Ex: PROD001"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome *
                  </label>
                  <input
                    type="text"
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                    placeholder="Nome do produto"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descrição
                  </label>
                  <textarea
                    value={formData.descricao}
                    onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                    placeholder="Descrição detalhada do produto..."
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Peso (kg)
                  </label>
                  <input
                    type="number"
                    value={formData.peso_kg}
                    onChange={(e) => setFormData(prev => ({ ...prev, peso_kg: e.target.value }))}
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Comprimento (m)
                    </label>
                    <input
                      type="number"
                      value={formData.comprimento_m}
                      onChange={(e) => setFormData(prev => ({ ...prev, comprimento_m: e.target.value }))}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Largura (m)
                    </label>
                    <input
                      type="number"
                      value={formData.largura_m}
                      onChange={(e) => setFormData(prev => ({ ...prev, largura_m: e.target.value }))}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Altura (m)
                    </label>
                    <input
                      type="number"
                      value={formData.altura_m}
                      onChange={(e) => setFormData(prev => ({ ...prev, altura_m: e.target.value }))}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                

                <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={() => setShowNewProduto(false)}
                    className="px-6 py-3 text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center space-x-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Salvando...</span>
                      </>
                    ) : (
                      <span>Salvar Produto</span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Upload Modal */}
        {showUploadModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-75">
            <div className="bg-white rounded-2xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900">Importar Produtos</h2>
                <p className="text-gray-600 mt-2">Envie um arquivo CSV com os produtos para importação em massa</p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <h3 className="text-sm font-medium text-blue-800 mb-2">Formato do arquivo Excel:</h3>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• <strong>codigo</strong> (obrigatório): Código único do produto</li>
                    <li>• <strong>nome</strong> (obrigatório): Nome/descrição do produto</li>
                    <li>• <strong>peso_kg</strong>: Peso em quilogramas (apenas número com 2 casas decimais)</li>
                    <li>• <strong>comprimento_m</strong>: Comprimento em metros</li>
                    <li>• <strong>largura_m</strong>: Largura em metros</li>
                    <li>• <strong>altura_m</strong>: Altura em metros</li>
                    <li>• <strong>m3</strong>: Volume em metros cúbicos (4 casas decimais)</li>
                  </ul>
                  <p className="text-xs text-blue-600 mt-2">
                    * O campo m3 será calculado automaticamente (4 casas decimais) se comprimento, largura e altura forem fornecidos
                  </p>
                </div>

                <div className="text-center">
                  <button
                    onClick={handleDownloadTemplate}
                    className="text-blue-600 hover:text-blue-800 underline text-sm"
                  >
                    Baixar template de exemplo
                  </button>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Selecionar arquivo Excel
                  </label>
                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileUpload}
                    disabled={isUploading}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                </div>

                {isUploading && (
                  <div className="flex items-center justify-center space-x-2 text-blue-600">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Processando arquivo...</span>
                  </div>
                )}

                <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={() => setShowUploadModal(false)}
                    disabled={isUploading}
                    className="px-6 py-3 text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
