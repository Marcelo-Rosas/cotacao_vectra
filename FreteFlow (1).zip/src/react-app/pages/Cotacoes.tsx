import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import Layout from '@/react-app/components/Layout';
import { get, post, patch, type APIResponse } from '@/react-app/lib/http';

import { 
  Plus, 
  Search, 
  FileText, 
  MapPin, 
  Calendar,
  DollarSign,
  Package,
  Filter,
  Loader2,
  AlertCircle,
  CheckCircle,
  LayoutGrid,
  List
} from 'lucide-react';
import type { Cotacao, Produto, NovaCotacao } from '@/shared/types';
import KanbanBoard from '@/react-app/components/KanbanBoard';
import { useForm } from 'react-hook-form';
import CepField from '@/react-app/components/CepField';
import MaskedField from '@/react-app/components/MaskedField';

export default function Cotacoes() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [cotacoes, setCotacoes] = useState<Cotacao[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [showNewCotacao, setShowNewCotacao] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [ambienteFilter, setAmbienteFilter] = useState('producao');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');

  // Check if user is admin - only admins can use Kanban view
  const isAdmin = user?.role === 'admin' ||
                  (user?.email?.toLowerCase().endsWith('@vectracargo.com.br') ?? false);
  
  const {
    register,
    handleSubmit: handleFormSubmit,
    setValue,
    watch,
    reset,
    formState: { errors }
  } = useForm<NovaCotacao>({
    defaultValues: {
      cep_origem: '',
      cep_destino: '',
      cidade_origem: '',
      cidade_destino: '',
      uf_origem: '',
      uf_destino: '',
      documento: '',
      tipo_documento: 'cnpj',
      nome_cliente: '',
      valor_nf: 0,
      ambiente: 'producao',
      itens: [],
      observacoes: ''
    }
  });

  const watchedValues = watch();

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login');
    }
  }, [user, isLoading, navigate]);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user, ambienteFilter]);

  const loadData = async () => {
    try {
      setLoadingData(true);
      
      const [cotacoesResponse, produtosResponse] = await Promise.all([
        get<APIResponse<Cotacao[]>>(`/api/cotacoes?ambiente=${ambienteFilter}`),
        get<APIResponse<Produto[]>>('/api/produtos')
      ]);

      setCotacoes(cotacoesResponse.data || []);
      setProdutos(produtosResponse.data || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoadingData(false);
    }
  };

  const onSubmit = async (data: NovaCotacao) => {
    setIsSubmitting(true);
    setMessage(null);

    try {
      const result = await post<APIResponse<{ numero_cotacao: string }>>('/api/cotacoes', data);
      setMessage({ type: 'success', text: `Cotação ${result.data?.numero_cotacao} criada com sucesso!` });
      setShowNewCotacao(false);
      reset();
      loadData();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao criar cotação';
      setMessage({ type: 'error', text: errorMessage });
    } finally {
      setIsSubmitting(false);
    }
  };

  const addItem = () => {
    const currentItens = watchedValues.itens || [];
    setValue('itens', [...currentItens, { produto_id: 0, quantidade: 1 }]);
  };

  const removeItem = (index: number) => {
    const currentItens = watchedValues.itens || [];
    setValue('itens', currentItens.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: 'produto_id' | 'quantidade', value: number) => {
    const currentItens = watchedValues.itens || [];
    const updatedItens = currentItens.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    );
    setValue('itens', updatedItens);
  };

  const filteredCotacoes = cotacoes.filter(cotacao => {
    const matchesSearch = cotacao.numero_cotacao?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cotacao.cidade_origem?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cotacao.cidade_destino?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cotacao.nome_cliente?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cotacao.cep_origem?.includes(searchTerm) ||
                         cotacao.cep_destino?.includes(searchTerm);
    const matchesStatus = !statusFilter || cotacao.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleUpdateStatus = async (cotacaoId: number, newStatus: string) => {
    try {
      // If closing a cotacao, ask for freight value and type
      let payload: any = { status: newStatus };
      
      if (newStatus === 'fechada') {
        const valorFreteStr = prompt('Digite o valor do frete (ex: 150.50):');
        const tipoFrete = confirm('Clique OK para FOB (com cashback) ou Cancelar para CIF (sem cashback)') ? 'FOB' : 'CIF';
        
        if (valorFreteStr) {
          const valorFrete = parseFloat(valorFreteStr.replace(',', '.'));
          if (!isNaN(valorFrete) && valorFrete > 0) {
            payload.valor_frete = valorFrete;
            payload.tipo_frete = tipoFrete;
          } else {
            setMessage({ type: 'error', text: 'Valor do frete inválido' });
            return;
          }
        } else {
          setMessage({ type: 'error', text: 'Valor do frete é obrigatório para fechar cotação' });
          return;
        }
      }
      
      await patch<APIResponse>(`/api/cotacoes/${cotacaoId}/status`, payload);

      if (newStatus === 'fechada' && payload.tipo_frete === 'FOB') {
        setMessage({ 
          type: 'success', 
          text: 'Cotação fechada com sucesso! Cashback calculado automaticamente.' 
        });
      } else {
        setMessage({ type: 'success', text: 'Status da cotação atualizado com sucesso!' });
      }
      loadData();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao atualizar status da cotação';
      setMessage({ type: 'error', text: errorMessage });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pendente': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'aprovada': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'fechada': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejeitada': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  if (isLoading || loadingData) {
    return (
      <Layout>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Cotações</h1>
            <p className="text-gray-600 mt-2">Gerencie suas solicitações de cotação de frete</p>
          </div>
          <div className="flex items-center space-x-3">
            {/* View Toggle - Only for ADMIN users */}
            {isAdmin && (
              <div className="flex items-center bg-gray-100 rounded-xl p-1">
                <button
                  onClick={() => setViewMode('list')}
                  className={`flex items-center px-3 py-2 rounded-lg transition-all duration-200 ${
                    viewMode === 'list'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <List className="w-4 h-4 mr-2" />
                  Lista
                </button>
                <button
                  onClick={() => setViewMode('kanban')}
                  className={`flex items-center px-3 py-2 rounded-lg transition-all duration-200 ${
                    viewMode === 'kanban'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <LayoutGrid className="w-4 h-4 mr-2" />
                  Kanban
                </button>
              </div>
            )}
            <button
              onClick={() => setShowNewCotacao(true)}
              className="flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 space-x-2"
            >
              <Plus className="w-5 h-5" />
              <span>Nova Cotação</span>
            </button>
          </div>
        </div>

        {message && (
          <div className={`p-4 rounded-xl flex items-center space-x-3 ${
            message.type === 'success' 
              ? 'bg-green-50 text-green-800 border border-green-200' 
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}>
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Filters */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Buscar por número, cliente, origem ou destino..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="pl-10 pr-8 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
              >
                <option value="">Todos os status</option>
                <option value="pendente">Pendente</option>
                <option value="aprovada">Aprovada</option>
                <option value="fechada">Fechada</option>
                <option value="rejeitada">Rejeitada</option>
              </select>
            </div>
            <div className="relative">
              <select
                value={ambienteFilter}
                onChange={(e) => setAmbienteFilter(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
              >
                <option value="producao">Produção</option>
                <option value="teste">Teste</option>
              </select>
            </div>
          </div>
        </div>

        {/* Content based on view mode - Kanban only for ADMIN */}
        {isAdmin && viewMode === 'kanban' ? (
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
            <KanbanBoard 
              cotacoes={filteredCotacoes} 
              onUpdateStatus={handleUpdateStatus}
            />
          </div>
        ) : (
          /* Cotações List */
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
          {filteredCotacoes.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">
                {searchTerm || statusFilter ? 'Nenhuma cotação encontrada' : 'Nenhuma cotação ainda'}
              </h3>
              <p className="text-gray-600 mb-6">
                {searchTerm || statusFilter 
                  ? 'Tente ajustar os filtros de busca'
                  : 'Comece criando sua primeira cotação de frete'
                }
              </p>
              {!searchTerm && !statusFilter && (
                <button
                  onClick={() => setShowNewCotacao(true)}
                  className="px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
                >
                  Criar Primeira Cotação
                </button>
              )}
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredCotacoes.map((cotacao) => (
                <div key={cotacao.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <h3 className="text-lg font-semibold text-gray-900">{cotacao.numero_cotacao}</h3>
                        <span className={`px-3 py-1 text-sm font-medium rounded-full border ${getStatusColor(cotacao.status!)}`}>
                          {cotacao.status}
                        </span>
                      </div>
                      
                      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm mb-3">
                        <div className="flex items-center space-x-2 text-gray-600">
                          <MapPin className="w-4 h-4" />
                          <span>De: {cotacao.cidade_origem || cotacao.cep_origem}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-gray-600">
                          <MapPin className="w-4 h-4" />
                          <span>Para: {cotacao.cidade_destino || cotacao.cep_destino}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <span>{formatDate(cotacao.created_at!)}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-gray-600">
                          <DollarSign className="w-4 h-4" />
                          <span>NF: {formatCurrency(cotacao.valor_nf)}</span>
                        </div>
                      </div>
                      
                      {/* Additional Info Row */}
                      <div className="grid md:grid-cols-3 gap-4 text-sm">
                        {cotacao.nome_cliente && (
                          <div className="text-gray-600">
                            <span className="font-medium">Cliente:</span> {cotacao.nome_cliente}
                          </div>
                        )}
                        {cotacao.peso_total_kg && (
                          <div className="text-gray-600">
                            <span className="font-medium">Peso:</span> {cotacao.peso_total_kg.toFixed(2)} kg
                          </div>
                        )}
                        {cotacao.volume_total_m3 && (
                          <div className="text-gray-600">
                            <span className="font-medium">Volume:</span> {cotacao.volume_total_m3.toFixed(4)} m³
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right ml-6">
                      {cotacao.valor_frete ? (
                        <div>
                          <p className="text-lg font-bold text-gray-900">{formatCurrency(cotacao.valor_frete)}</p>
                          <p className="text-sm text-gray-500">Valor do frete</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-lg font-medium text-gray-500">Aguardando</p>
                          <p className="text-sm text-gray-400">Cotação</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          </div>
        )}

        {/* New Cotacao Modal */}
        {showNewCotacao && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-75">
            <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900">Nova Cotação</h2>
              </div>
              
              <form onSubmit={handleFormSubmit(onSubmit)} className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome do Cliente
                  </label>
                  <input
                    type="text"
                    {...register('nome_cliente')}
                    placeholder="Nome da empresa ou pessoa"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ambiente *
                    </label>
                    <select
                      {...register('ambiente')}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="producao">Produção</option>
                      <option value="teste">Teste</option>
                    </select>
                  </div>
                  
                  <div>
                    <CepField
                      label="CEP Origem *"
                      name="cep_origem"
                      value={watchedValues.cep_origem}
                      onChange={(value) => setValue('cep_origem', value)}
                      setValue={setValue as any}
                      map={{
                        cidade: 'cidade_origem',
                        uf: 'uf_origem'
                      }}
                      required
                      error={errors.cep_origem?.message}
                    />
                  </div>
                  
                  <div>
                    <CepField
                      label="CEP Destino *"
                      name="cep_destino"
                      value={watchedValues.cep_destino}
                      onChange={(value) => setValue('cep_destino', value)}
                      setValue={setValue as any}
                      map={{
                        cidade: 'cidade_destino',
                        uf: 'uf_destino'
                      }}
                      required
                      error={errors.cep_destino?.message}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cidade Origem
                    </label>
                    <input
                      type="text"
                      {...register('cidade_origem')}
                      placeholder="Nome da cidade (opcional)"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cidade Destino
                    </label>
                    <input
                      type="text"
                      {...register('cidade_destino')}
                      placeholder="Nome da cidade (opcional)"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tipo de Documento *
                    </label>
                    <select
                      {...register('tipo_documento')}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="cnpj">CNPJ</option>
                      <option value="cpf">CPF</option>
                    </select>
                  </div>
                  
                  <div>
                    <MaskedField
                      type="documento"
                      tipoDocumento={watchedValues.tipo_documento}
                      name="documento"
                      value={watchedValues.documento}
                      onChange={(value) => setValue('documento', value)}
                      required
                      error={errors.documento?.message}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Valor da Nota Fiscal *
                  </label>
                  <input
                    type="number"
                    {...register('valor_nf', { 
                      required: 'Valor da NF é obrigatório',
                      min: { value: 0.01, message: 'Valor deve ser maior que zero' }
                    })}
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.valor_nf && (
                    <p className="text-sm text-red-600 mt-1">{errors.valor_nf.message}</p>
                  )}
                </div>

                {/* Produtos */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <label className="block text-sm font-medium text-gray-700">
                      Produtos *
                    </label>
                    <button
                      type="button"
                      onClick={addItem}
                      className="flex items-center px-3 py-2 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Adicionar
                    </button>
                  </div>
                  
                  {(watchedValues.itens || []).length === 0 ? (
                    <div className="text-center py-6 border-2 border-dashed border-gray-300 rounded-xl">
                      <Package className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">Nenhum produto adicionado</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {(watchedValues.itens || []).map((item, index) => (
                        <div key={index} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg">
                          <select
                            value={item.produto_id}
                            onChange={(e) => updateItem(index, 'produto_id', Number(e.target.value))}
                            required
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          >
                            <option value="">Selecione um produto</option>
                            {produtos.map(produto => (
                              <option key={produto.id} value={produto.id}>
                                {produto.codigo} - {produto.nome}
                              </option>
                            ))}
                          </select>
                          <input
                            type="number"
                            value={item.quantidade}
                            onChange={(e) => updateItem(index, 'quantidade', Number(e.target.value))}
                            placeholder="Qtd"
                            min="1"
                            required
                            className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                          <button
                            type="button"
                            onClick={() => removeItem(index)}
                            className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            ✕
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Observações
                  </label>
                  <textarea
                    {...register('observacoes')}
                    placeholder="Informações adicionais sobre a cotação..."
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={() => setShowNewCotacao(false)}
                    className="px-6 py-3 text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting || (watchedValues.itens || []).length === 0}
                    className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center space-x-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Criando...</span>
                      </>
                    ) : (
                      <span>Criar Cotação</span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
