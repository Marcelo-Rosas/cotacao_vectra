import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AuthCallback() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to login - this callback page is not needed for our auth system
    navigate('/login');
  }, [navigate]);

  return null; // This component just redirects
}
