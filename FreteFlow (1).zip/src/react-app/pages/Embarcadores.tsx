import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import Layout from '@/react-app/components/Layout';
import { 
  Building2, Search, Filter, Trash2, Clock, CheckCircle, 
  User, Mail, Shield, Calendar,
  RefreshCw, Zap
} from 'lucide-react';
import type { SistemaEmbarcador, SolicitacaoCadastro } from '@/shared/types';

export default function Embarcadores() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [embarcadores, setEmbarcadores] = useState<SistemaEmbarcador[]>([]);
  const [solicitacoesAprovadas, setSolicitacoesAprovadas] = useState<SolicitacaoCadastro[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingAprovadas, setLoadingAprovadas] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showActiveOnly, setShowActiveOnly] = useState(true);
  const [deleteLoading, setDeleteLoading] = useState<string | null>(null);

  // Check if user is admin - based on role or Vectra email
  const isAdmin = user?.role === 'admin' ||
                  (user?.email?.toLowerCase().endsWith('@vectracargo.com.br') ?? false);

  useEffect(() => {
    if (isLoading) return;
    if (!user) {
      navigate('/login');
      return;
    }
    
    if (isAdmin) {
      loadEmbarcadores();
      loadSolicitacoesAprovadas();
    }
  }, [user, isAdmin, isLoading, navigate]);

  const loadEmbarcadores = async () => {
    try {
      setLoading(true);
      console.log('[EMBARCADORES] Loading embarcadores...');
      
      const response = await fetch('/api/sistema-embarcadores', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('[EMBARCADORES] Loaded:', data.length, 'embarcadores');
        setEmbarcadores(data);
      } else {
        console.error('[EMBARCADORES] Error loading:', response.status);
      }
    } catch (error) {
      console.error('[EMBARCADORES] Error loading embarcadores:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadSolicitacoesAprovadas = async () => {
    try {
      setLoadingAprovadas(true);
      console.log('[EMBARCADORES] Loading approved solicitations...');
      
      const response = await fetch('/api/solicitacoes-cadastro?status=APROVADO', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Filtrar apenas aprovadas dos últimos 30 dias
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const aprovadas = data
          .filter((sol: SolicitacaoCadastro) => 
            sol.status === 'APROVADO' && 
            new Date(sol.updated_at!) >= thirtyDaysAgo
          )
          .slice(0, 10); // Limitar aos 10 mais recentes
          
        console.log('[EMBARCADORES] Approved in last 30 days:', aprovadas.length);
        setSolicitacoesAprovadas(aprovadas);
      } else {
        console.error('[EMBARCADORES] Error loading approved solicitations:', response.status);
      }
    } catch (error) {
      console.error('[EMBARCADORES] Error loading approved solicitations:', error);
    } finally {
      setLoadingAprovadas(false);
    }
  };

  const handleDeleteEmbarcador = async (id: string, nomeEmpresa: string) => {
    if (!confirm(`⚠️ ATENÇÃO: Esta ação é irreversível!

Você está prestes a excluir:
• Embarcador: ${nomeEmpresa}
• Todos os produtos cadastrados
• Todas as cotações realizadas  
• Todos os usuários de acesso
• Todo histórico relacionado

Esta ação não pode ser desfeita. Tem certeza que deseja continuar?`)) {
      return;
    }

    try {
      setDeleteLoading(id);
      console.log('[EMBARCADORES] Deleting embarcador:', id);
      
      const response = await fetch(`/api/sistema-embarcadores/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok) {
        console.log('[EMBARCADORES] Embarcador deleted successfully');
        await loadEmbarcadores(); // Reload list
        alert('✅ Embarcador excluído com sucesso!');
      } else {
        const errorData = await response.json();
        console.error('[EMBARCADORES] Error deleting:', errorData);
        alert(`❌ Erro ao excluir embarcador: ${errorData.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('[EMBARCADORES] Error deleting embarcador:', error);
      alert('❌ Erro ao excluir embarcador');
    } finally {
      setDeleteLoading(null);
    }
  };

  const filteredEmbarcadores = embarcadores.filter(embarcador => {
    const matchesSearch = embarcador.nome_empresa.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         embarcador.cnpj?.includes(searchTerm) ||
                         embarcador.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesActive = !showActiveOnly || embarcador.ativo;
    return matchesSearch && matchesActive;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isAdmin) {
    return (
      <Layout>
        <div className="text-center py-12">
          <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Acesso Restrito</h1>
          <p className="text-gray-600">Esta página é exclusiva para administradores do FreteFlow.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-3">
              <Building2 className="w-8 h-8 text-blue-600" />
              <span>Embarcadores</span>
            </h1>
            <p className="text-gray-600 mt-2">Gestão de embarcadores do sistema FreteFlow</p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => {
                loadEmbarcadores();
                loadSolicitacoesAprovadas();
              }}
              disabled={loading || loadingAprovadas}
              className="bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2"
            >
              {(loading || loadingAprovadas) ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Atualizando...</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-5 h-5" />
                  <span>Atualizar</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Processamentos Recentes Automáticos */}
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8 border border-green-200 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-500 rounded-lg">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Processamentos Recentes</h2>
                <p className="text-gray-600">Solicitações processadas nos últimos 30 dias</p>
              </div>
            </div>
          </div>

          {loadingAprovadas ? (
            <div className="flex items-center justify-center py-8">
              <div className="w-6 h-6 border-2 border-green-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="ml-2 text-gray-600">Carregando processamentos...</span>
            </div>
          ) : solicitacoesAprovadas.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum processamento recente</h3>
              <p className="text-gray-600 mb-4">Não há solicitações processadas nos últimos 30 dias.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {solicitacoesAprovadas.map((solicitacao) => (
                <div key={solicitacao.id} className="bg-white rounded-xl p-6 border border-green-100 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-green-100 rounded-lg">
                        <Building2 className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">{solicitacao.nome_empresa}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                          <span className="flex items-center space-x-1">
                            <User className="w-4 h-4" />
                            <span>{solicitacao.contato_nome}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Mail className="w-4 h-4" />
                            <span>{solicitacao.contato_email}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-2 text-green-600 mb-1">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-medium">Processado</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        por {solicitacao.respondido_por}
                      </div>
                      <div className="text-xs text-gray-500">
                        {formatDate(solicitacao.updated_at!)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Building2 className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{embarcadores.length}</div>
                <div className="text-sm text-gray-600">Total de Embarcadores</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">{embarcadores.filter(e => e.ativo).length}</div>
                <div className="text-sm text-gray-600">Ativos</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-600">{embarcadores.filter(e => !e.ativo).length}</div>
                <div className="text-sm text-gray-600">Inativos</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-emerald-100 rounded-lg">
                <Zap className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-emerald-600">{solicitacoesAprovadas.length}</div>
                <div className="text-sm text-gray-600">Processados (30d)</div>
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Lista de Embarcadores</h2>
            <div className="text-sm text-gray-600">
              {filteredEmbarcadores.length} de {embarcadores.length} embarcadores
            </div>
          </div>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Buscar por empresa, CNPJ ou email..."
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button
              onClick={() => setShowActiveOnly(!showActiveOnly)}
              className={`flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-colors ${
                showActiveOnly
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Filter className="w-5 h-5" />
              <span>Apenas Ativos</span>
            </button>
          </div>

          {/* Embarcadores List */}
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="ml-2 text-gray-600">Carregando embarcadores...</span>
            </div>
          ) : filteredEmbarcadores.length === 0 ? (
            <div className="text-center py-12">
              <Building2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {searchTerm ? 'Nenhum embarcador encontrado' : 'Nenhum embarcador cadastrado'}
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm 
                  ? 'Tente ajustar os termos de busca.'
                  : 'Embarcadores aparecerão aqui após serem criados.'
                }
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEmbarcadores.map((embarcador) => (
                <div key={embarcador.id} className="bg-gray-50 rounded-xl p-6 border border-gray-200 hover:shadow-md transition-all duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`p-3 rounded-lg ${embarcador.ativo ? 'bg-green-100' : 'bg-gray-100'}`}>
                        <Building2 className={`w-6 h-6 ${embarcador.ativo ? 'text-green-600' : 'text-gray-400'}`} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{embarcador.nome_empresa}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                          {embarcador.cnpj && (
                            <span>CNPJ: {embarcador.cnpj}</span>
                          )}
                          {embarcador.email && (
                            <span className="flex items-center space-x-1">
                              <Mail className="w-4 h-4" />
                              <span>{embarcador.email}</span>
                            </span>
                          )}
                          <span className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>{formatDate(embarcador.created_at!)}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {/* Status Badge */}
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                        embarcador.ativo
                          ? 'bg-green-100 text-green-800 border border-green-200'
                          : 'bg-gray-100 text-gray-800 border border-gray-200'
                      }`}>
                        {embarcador.ativo ? 'Ativo' : 'Inativo'}
                      </span>
                      
                      {/* Actions */}
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleDeleteEmbarcador(embarcador.id!, embarcador.nome_empresa)}
                          disabled={deleteLoading === embarcador.id}
                          className="bg-red-500 hover:bg-red-600 disabled:bg-gray-300 text-white p-2 rounded-lg transition-colors"
                          title="Excluir embarcador"
                        >
                          {deleteLoading === embarcador.id ? (
                            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          ) : (
                            <Trash2 className="w-5 h-5" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 grid md:grid-cols-3 gap-4 text-sm">
                    <div className="bg-white rounded-lg p-3 border border-gray-200">
                      <div className="flex items-center space-x-2 text-gray-600 mb-1">
                        <User className="w-4 h-4" />
                        <span className="font-medium">Usuários Máx.</span>
                      </div>
                      <p className="font-semibold text-gray-900">{embarcador.max_users}</p>
                    </div>
                    {embarcador.telefone && (
                      <div className="bg-white rounded-lg p-3 border border-gray-200">
                        <div className="flex items-center space-x-2 text-gray-600 mb-1">
                          <Clock className="w-4 h-4" />
                          <span className="font-medium">Telefone</span>
                        </div>
                        <p className="font-semibold text-gray-900">{embarcador.telefone}</p>
                      </div>
                    )}
                    <div className="bg-white rounded-lg p-3 border border-gray-200">
                      <div className="flex items-center space-x-2 text-gray-600 mb-1">
                        <Calendar className="w-4 h-4" />
                        <span className="font-medium">Últ. Atualização</span>
                      </div>
                      <p className="font-semibold text-gray-900 text-sm">{formatDate(embarcador.updated_at!)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
