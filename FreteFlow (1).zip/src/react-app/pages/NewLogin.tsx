import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/react-app/providers/AuthProvider';
import LoginForm from '@/react-app/components/LoginForm';
import { Truck } from 'lucide-react';

export default function NewLogin() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && user) {
      navigate('/dashboard');
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="animate-spin">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl shadow-xl">
              <Truck className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">FreteFlow</h1>
          <p className="text-gray-600 mt-1">Sistema de cotações de frete</p>
        </div>

        {/* Formulário de Login */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <LoginForm />
        </div>

        {/* Links */}
        <div className="text-center mt-6">
          <p className="text-sm text-gray-500">
            Não tem uma conta?{' '}
            <button
              onClick={() => navigate('/cadastro')}
              className="text-blue-600 hover:text-blue-500 font-medium"
            >
              Cadastre sua empresa
            </button>
          </p>
        </div>

        <div className="text-center mt-4">
          <button
            onClick={() => navigate('/')}
            className="text-blue-600 hover:text-blue-500 font-medium"
          >
            ← Voltar para página inicial
          </button>
        </div>
      </div>
    </div>
  );
}
