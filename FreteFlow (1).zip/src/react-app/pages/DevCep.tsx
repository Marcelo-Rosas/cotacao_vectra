import { useState } from 'react';
import { useForm } from 'react-hook-form';
import Layout from '@/react-app/components/Layout';
import CepField from '@/react-app/components/CepField';
import MaskedField from '@/react-app/components/MaskedField';
import { MapPin, Code, User, Mail, FileText } from 'lucide-react';
import type { CepData } from '@/react-app/hooks/useCepAutofill';

interface DemoForm {
  cep: string;
  cidade: string;
  estado: string;
  bairro: string;
  logradouro: string;
  nome: string;
  email: string;
  cnpj: string;
  cpf: string;
  telefone: string;
  tipo_documento: 'cnpj' | 'cpf';
}

export default function DevCep() {
  const [lastAutofillData, setLastAutofillData] = useState<CepData | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors }
  } = useForm<DemoForm>({
    defaultValues: {
      cep: '',
      cidade: '',
      estado: '',
      bairro: '',
      logradouro: '',
      nome: '',
      email: '',
      cnpj: '',
      cpf: '',
      telefone: '',
      tipo_documento: 'cnpj'
    }
  });

  // Watch form values for display
  const watchedValues = watch();

  const onSubmit = (data: DemoForm) => {
    console.log('Form submitted:', data);
    alert('Formulário enviado! Confira o console para ver os dados.');
  };

  const handleAutofill = (data: CepData) => {
    setLastAutofillData(data);
    console.log('CEP autofilled:', data);
  };

  const testCeps = [
    { cep: '01001-000', desc: 'Sé, São Paulo - SP' },
    { cep: '20040-020', desc: 'Centro, Rio de Janeiro - RJ' },
    { cep: '30130-000', desc: 'Centro, Belo Horizonte - MG' },
    { cep: '80010-000', desc: 'Centro, Curitiba - PR' },
    { cep: '88010-000', desc: 'Centro, Florianópolis - SC' }
  ];

  const fillTestCep = (cep: string) => {
    setValue('cep', cep);
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            🛠️ Demo: Sistema de Máscaras e CEP
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Demonstração dos componentes CepField e MaskedField com máscaras automáticas 
            para CEP (BrasilAPI + ViaCEP), CNPJ, CPF e telefone.
          </p>
        </div>

        {/* Quick Test CEPs */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-blue-900 mb-4 flex items-center space-x-2">
            <Code className="w-5 h-5" />
            <span>CEPs para Teste</span>
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {testCeps.map((test) => (
              <button
                key={test.cep}
                onClick={() => fillTestCep(test.cep)}
                className="text-left p-3 bg-white border border-blue-200 rounded-lg hover:shadow-md transition-all duration-200 hover:border-blue-300"
              >
                <div className="font-mono text-blue-600 font-semibold">{test.cep}</div>
                <div className="text-sm text-gray-600">{test.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form Demo */}
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Formulário de Exemplo</span>
            </h2>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* CEP Field with autofill */}
              <CepField
                name="cep"
                value={watchedValues.cep}
                onChange={(value) => setValue('cep', value)}
                onAutofill={handleAutofill}
                setValue={setValue as any}
                map={{
                  cidade: 'cidade',
                  estado: 'estado',
                  bairro: 'bairro',
                  logradouro: 'logradouro'
                }}
                required
                error={errors.cep?.message}
              />

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Cidade *
                  </label>
                  <input
                    type="text"
                    {...register('cidade', { required: 'Cidade é obrigatória' })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Cidade"
                  />
                  {errors.cidade && (
                    <p className="text-sm text-red-600 mt-1">{errors.cidade.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Estado *
                  </label>
                  <input
                    type="text"
                    {...register('estado', { required: 'Estado é obrigatório' })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="UF"
                    maxLength={2}
                  />
                  {errors.estado && (
                    <p className="text-sm text-red-600 mt-1">{errors.estado.message}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Bairro
                </label>
                <input
                  type="text"
                  {...register('bairro')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Bairro"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Logradouro
                </label>
                <input
                  type="text"
                  {...register('logradouro')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Rua, Avenida, etc."
                />
              </div>

              <hr className="border-gray-200" />

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome Completo *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    {...register('nome', { required: 'Nome é obrigatório' })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Seu nome completo"
                  />
                </div>
                {errors.nome && (
                  <p className="text-sm text-red-600 mt-1">{errors.nome.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  E-mail *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    {...register('email', {
                      required: 'E-mail é obrigatório',
                      pattern: {
                        value: /^\S+@\S+$/i,
                        message: 'E-mail inválido'
                      }
                    })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="seu@email.com"
                  />
                </div>
                {errors.email && (
                  <p className="text-sm text-red-600 mt-1">{errors.email.message}</p>
                )}
              </div>

              <hr className="border-gray-200" />

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de Documento
                </label>
                <select
                  {...register('tipo_documento')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="cnpj">CNPJ</option>
                  <option value="cpf">CPF</option>
                </select>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <MaskedField
                  type="cnpj"
                  name="cnpj"
                  value={watchedValues.cnpj}
                  onChange={(value) => setValue('cnpj', value)}
                />

                <MaskedField
                  type="cpf"
                  name="cpf"
                  value={watchedValues.cpf}
                  onChange={(value) => setValue('cpf', value)}
                />
              </div>

              <MaskedField
                type="telefone"
                name="telefone"
                value={watchedValues.telefone}
                onChange={(value) => setValue('telefone', value)}
              />

              <div>
                <MaskedField
                  type="documento"
                  tipoDocumento={watchedValues.tipo_documento}
                  name="documento_dinamico"
                  label="Documento Dinâmico (muda conforme o tipo)"
                  placeholder={watchedValues.tipo_documento === 'cnpj' ? '00.000.000/0000-00' : '000.000.000-00'}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-200"
              >
                Enviar Formulário
              </button>
            </form>
          </div>

          {/* Debug Panel */}
          <div className="space-y-6">
            {/* Current Form Data */}
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                📊 Dados do Formulário
              </h3>
              <pre className="text-sm bg-white p-4 rounded-lg border overflow-x-auto">
                {JSON.stringify(watchedValues, null, 2)}
              </pre>
            </div>

            {/* Last Autofill Data */}
            {lastAutofillData && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-green-900 mb-4 flex items-center space-x-2">
                  <MapPin className="w-5 h-5" />
                  <span>Último Autopreenchimento</span>
                </h3>
                <div className="space-y-2 text-sm">
                  <div><strong>CEP:</strong> {lastAutofillData.cep}</div>
                  <div><strong>Cidade:</strong> {lastAutofillData.cidade}</div>
                  <div><strong>UF:</strong> {lastAutofillData.uf}</div>
                  <div><strong>Bairro:</strong> {lastAutofillData.bairro}</div>
                  <div><strong>Logradouro:</strong> {lastAutofillData.logradouro}</div>
                  <div><strong>Provider:</strong> {lastAutofillData.provider}</div>
                </div>
              </div>
            )}

            {/* Usage Instructions */}
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <FileText className="w-5 h-5" />
                <span>💡 Como Usar</span>
              </h3>
              <div className="space-y-4 text-sm text-gray-600">
                <div>
                  <strong className="text-gray-900">1. CepField (autopreenchimento):</strong>
                  <code className="block bg-gray-100 p-2 rounded mt-1 text-xs font-mono">
                    {`<CepField 
  name="cep"
  setValue={setValue}
  map={{ cidade: 'cidade', estado: 'estado' }}
/>`}
                  </code>
                </div>
                <div>
                  <strong className="text-gray-900">2. MaskedField CNPJ:</strong>
                  <code className="block bg-gray-100 p-2 rounded mt-1 text-xs font-mono">
                    {`<MaskedField 
  type="cnpj"
  name="cnpj"
  value={value}
  onChange={setValue}
/>`}
                  </code>
                </div>
                <div>
                  <strong className="text-gray-900">3. MaskedField CPF:</strong>
                  <code className="block bg-gray-100 p-2 rounded mt-1 text-xs font-mono">
                    {`<MaskedField 
  type="cpf"
  name="cpf"
  required
/>`}
                  </code>
                </div>
                <div>
                  <strong className="text-gray-900">4. MaskedField Telefone:</strong>
                  <code className="block bg-gray-100 p-2 rounded mt-1 text-xs font-mono">
                    {`<MaskedField 
  type="telefone"
  name="telefone"
/>`}
                  </code>
                </div>
                <div>
                  <strong className="text-gray-900">5. Documento dinâmico (CNPJ/CPF):</strong>
                  <code className="block bg-gray-100 p-2 rounded mt-1 text-xs font-mono">
                    {`<MaskedField 
  type="documento"
  tipoDocumento={tipoDoc} // 'cnpj' ou 'cpf'
  name="documento"
/>`}
                  </code>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
