import { useEffect, useMemo, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import Layout from "@/react-app/components/Layout";
import { ProdutosAPI } from "@/react-app/services/produtos";

type ProdutoForm = {
  id?: string;
  sku: string;
  name: string;
  ncm?: string | null;
  unit?: string | null;
  price_display?: string; // campo amigável (R$) -> converte para price_cents no submit
  price_cents?: number;   // enviado ao backend
  weight_kg?: number | null;
  length_cm?: number | null;
  width_cm?: number | null;
  height_cm?: number | null;
  active?: 0 | 1;
};

type Produto = Parameters<typeof ProdutosAPI.create>[0] & {
  id: string;
  price_cents: number;
  created_at: string;
  updated_at: string;
  active: 0 | 1;
};

function centsToBRL(cents: number) {
  const v = (cents ?? 0) / 100;
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function brlToCents(text: string | undefined): number {
  if (!text) return 0;
  // remove tudo que não número/comma/dot
  const cleaned = text.replace(/[^\d,.-]/g, "").replace(".", "").replace(",", ".");
  const num = Number(cleaned);
  if (!isFinite(num)) return 0;
  return Math.round(num * 100);
}

export default function ProdutosPage() {
  // tabela / filtros
  const [items, setItems] = useState<Produto[]>([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [activeFilter, setActiveFilter] = useState<"" | "1" | "0">("");
  const [loadingList, setLoadingList] = useState(false);

  // modal
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Produto | null>(null);
  const [saving, setSaving] = useState(false);
  const [removingId, setRemovingId] = useState<string | null>(null);

  const { handleSubmit, control, reset } = useForm<ProdutoForm>({
    defaultValues: {
      sku: "",
      name: "",
      ncm: "",
      unit: "UN",
      price_display: "",
      active: 1,
    },
  });

  // carregar lista
  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        setLoadingList(true);
        const resp = await ProdutosAPI.list({
          search: search.trim() || undefined,
          page,
          pageSize,
          active: activeFilter === "" ? undefined : (activeFilter === "1" ? 1 : 0),
        });
        if (ignore) return;
        setItems((resp as any).items ?? resp.items);
        setTotal((resp as any).total ?? resp.total);
      } catch (e: any) {
        console.error("Erro ao listar produtos", e);
        alert(e?.error ?? "Erro ao listar produtos");
      } finally {
        if (!ignore) setLoadingList(false);
      }
    })();
    return () => {
      ignore = true;
    };
  }, [search, page, pageSize, activeFilter]);

  // abrir para criar
  function onCreate() {
    setEditing(null);
    reset({
      sku: "",
      name: "",
      ncm: "",
      unit: "UN",
      price_display: "",
      active: 1,
    });
    setOpen(true);
  }

  // abrir para editar
  function onEdit(p: Produto) {
    setEditing(p);
    reset({
      id: p.id,
      sku: p.sku,
      name: p.name,
      ncm: (p as any).ncm ?? "",
      unit: (p as any).unit ?? "UN",
      price_display: centsToBRL(p.price_cents),
      price_cents: p.price_cents,
      weight_kg: (p as any).weight_kg ?? undefined,
      length_cm: (p as any).length_cm ?? undefined,
      width_cm: (p as any).width_cm ?? undefined,
      height_cm: (p as any).height_cm ?? undefined,
      active: p.active,
    });
    setOpen(true);
  }

  // submit
  const onSubmit = handleSubmit(async (data) => {
    try {
      setSaving(true);
      const payload = {
        sku: data.sku.trim(),
        name: data.name.trim(),
        ncm: data.ncm?.toString().trim() || null,
        unit: data.unit?.toString().trim() || null,
        price_cents: brlToCents(data.price_display),
        weight_kg: data.weight_kg != null ? Number(data.weight_kg) : undefined,
        length_cm: data.length_cm != null ? Number(data.length_cm) : undefined,
        width_cm: data.width_cm != null ? Number(data.width_cm) : undefined,
        height_cm: data.height_cm != null ? Number(data.height_cm) : undefined,
        active: data.active ?? 1,
      };

      if (editing) {
        const res = await ProdutosAPI.update(editing.id, payload as any);
        if (!res.success) throw res;
      } else {
        const res = await ProdutosAPI.create(payload as any);
        if (!res.success) throw res;
      }

      setOpen(false);
      // refresh mantendo a página
      const keepPage = page;
      setPage(keepPage); // dispara useEffect
    } catch (e: any) {
      console.error("Erro ao salvar produto", e);
      alert(e?.error ?? "Erro ao salvar produto");
    } finally {
      setSaving(false);
    }
  });

  // remover (soft)
  async function onRemove(p: Produto) {
    if (!confirm(`Remover produto "${p.name}"?`)) return;
    try {
      setRemovingId(p.id);
      const res = await ProdutosAPI.remove(p.id, false);
      if (!res.success) throw res;
      // se listagem ficou vazia na página atual, volta 1 página
      const remaining = items.length - 1;
      if (remaining <= 0 && page > 1) setPage(page - 1);
      else setPage(page); // recarrega
    } catch (e: any) {
      console.error("Erro ao remover", e);
      alert(e?.error ?? "Erro ao remover");
    } finally {
      setRemovingId(null);
    }
  }

  const totalPages = useMemo(
    () => Math.max(1, Math.ceil(total / pageSize)),
    [total, pageSize]
  );

  return (
    <Layout title="Produtos">
      <div className="max-w-6xl mx-auto p-4 space-y-4">
        <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-semibold">Produtos</h1>
          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            <input
              placeholder="Buscar por SKU ou Nome…"
              className="border rounded px-3 py-2 w-full sm:w-64"
              value={search}
              onChange={(e) => {
                setPage(1);
                setSearch(e.target.value);
              }}
            />
            <select
              className="border rounded px-3 py-2"
              value={activeFilter}
              onChange={(e) => {
                setPage(1);
                setActiveFilter(e.target.value as any);
              }}
            >
              <option value="">Todos</option>
              <option value="1">Ativos</option>
              <option value="0">Inativos</option>
            </select>
            <button
              onClick={onCreate}
              className="bg-black text-white rounded px-4 py-2"
            >
              Novo produto
            </button>
          </div>
        </header>

        <section className="border rounded">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-2">SKU</th>
                  <th className="text-left p-2">Nome</th>
                  <th className="text-left p-2">Unid.</th>
                  <th className="text-left p-2">Preço</th>
                  <th className="text-left p-2">Ativo</th>
                  <th className="text-left p-2 w-40">Ações</th>
                </tr>
              </thead>
              <tbody>
                {loadingList ? (
                  <tr>
                    <td className="p-3" colSpan={6}>
                      Carregando…
                    </td>
                  </tr>
                ) : items.length === 0 ? (
                  <tr>
                    <td className="p-3" colSpan={6}>
                      Nenhum produto encontrado.
                    </td>
                  </tr>
                ) : (
                  items.map((p) => (
                    <tr key={p.id} className="border-t">
                      <td className="p-2">{p.sku}</td>
                      <td className="p-2">{p.name}</td>
                      <td className="p-2">{(p as any).unit ?? "—"}</td>
                      <td className="p-2">{centsToBRL(p.price_cents)}</td>
                      <td className="p-2">
                        {p.active ? (
                          <span className="text-green-700">Ativo</span>
                        ) : (
                          <span className="text-gray-500">Inativo</span>
                        )}
                      </td>
                      <td className="p-2">
                        <div className="flex gap-2">
                          <button
                            className="border rounded px-3 py-1"
                            onClick={() => onEdit(p)}
                          >
                            Editar
                          </button>
                          <button
                            className="border rounded px-3 py-1 text-red-700"
                            onClick={() => onRemove(p)}
                            disabled={removingId === p.id}
                          >
                            {removingId === p.id ? "Removendo…" : "Remover"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <footer className="flex items-center justify-between p-3 text-sm">
            <div>
              {total} registro(s) • Página {page} de {totalPages}
            </div>
            <div className="flex items-center gap-2">
              <button
                className="border rounded px-2 py-1"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
              >
                ◀
              </button>
              <select
                className="border rounded px-2 py-1"
                value={pageSize}
                onChange={(e) => {
                  setPage(1);
                  setPageSize(Number(e.target.value));
                }}
              >
                {[10, 20, 50, 100].map((n) => (
                  <option key={n} value={n}>
                    {n}/página
                  </option>
                ))}
              </select>
              <button
                className="border rounded px-2 py-1"
                onClick={() =>
                  setPage((p) => (p < totalPages ? p + 1 : p))
                }
                disabled={page >= totalPages}
              >
                ▶
              </button>
            </div>
          </footer>
        </section>
      </div>

      {/* Modal simples */}
      {open && (
        <div
          className="fixed inset-0 bg-black/30 flex items-center justify-center z-50"
          onClick={() => !saving && setOpen(false)}
        >
          <div
            className="bg-white w-full max-w-2xl rounded p-4 shadow"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold">
                {editing ? "Editar produto" : "Novo produto"}
              </h2>
              <button
                className="border rounded px-3 py-1"
                onClick={() => !saving && setOpen(false)}
              >
                Fechar
              </button>
            </div>

            <form
              className="grid grid-cols-1 sm:grid-cols-2 gap-3"
              onSubmit={onSubmit}
            >
              <Controller
                name="sku"
                control={control}
                rules={{ required: "Informe o SKU" }}
                render={({ field, fieldState }) => (
                  <div>
                    <label className="block text-sm mb-1">SKU *</label>
                    <input
                      {...field}
                      className="w-full border rounded px-3 py-2"
                      placeholder="ex: ABC-001"
                    />
                    {fieldState.error && (
                      <p className="text-red-600 text-xs mt-1">
                        {fieldState.error.message}
                      </p>
                    )}
                  </div>
                )}
              />

              <Controller
                name="name"
                control={control}
                rules={{ required: "Informe o nome" }}
                render={({ field, fieldState }) => (
                  <div>
                    <label className="block text-sm mb-1">Nome *</label>
                    <input
                      {...field}
                      className="w-full border rounded px-3 py-2"
                      placeholder="ex: Caixa de papelão"
                    />
                    {fieldState.error && (
                      <p className="text-red-600 text-xs mt-1">
                        {fieldState.error.message}
                      </p>
                    )}
                  </div>
                )}
              />

              <Controller
                name="unit"
                control={control}
                render={({ field }) => (
                  <div>
                    <label className="block text-sm mb-1">Unidade</label>
                    <input
                      {...field}
                      value={field.value ?? ""}
                      className="w-full border rounded px-3 py-2"
                      placeholder="UN, CX, KG…"
                    />
                  </div>
                )}
              />

              <Controller
                name="ncm"
                control={control}
                render={({ field }) => (
                  <div>
                    <label className="block text-sm mb-1">NCM</label>
                    <input
                      {...field}
                      value={field.value ?? ""}
                      className="w-full border rounded px-3 py-2"
                      placeholder="ex: 4819.10.00"
                    />
                  </div>
                )}
              />

              <Controller
                name="price_display"
                control={control}
                render={({ field }) => (
                  <div className="sm:col-span-2">
                    <label className="block text-sm mb-1">Preço</label>
                    <input
                      {...field}
                      className="w-full border rounded px-3 py-2"
                      placeholder="R$ 0,00"
                      onChange={(e) => {
                        // permite digitar livre; converte no submit
                        field.onChange(e.target.value);
                      }}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      O valor será convertido automaticamente para centavos.
                    </p>
                  </div>
                )}
              />

              <div className="sm:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Controller
                  name="weight_kg"
                  control={control}
                  render={({ field }) => (
                    <div>
                      <label className="block text-sm mb-1">Peso (kg)</label>
                      <input
                        type="number"
                        step="0.001"
                        {...field}
                        value={field.value ?? ""}
                        className="w-full border rounded px-3 py-2"
                        placeholder="0.000"
                      />
                    </div>
                  )}
                />
                <Controller
                  name="length_cm"
                  control={control}
                  render={({ field }) => (
                    <div>
                      <label className="block text-sm mb-1">Compr. (cm)</label>
                      <input
                        type="number"
                        step="0.01"
                        {...field}
                        value={field.value ?? ""}
                        className="w-full border rounded px-3 py-2"
                        placeholder="0.00"
                      />
                    </div>
                  )}
                />
                <Controller
                  name="width_cm"
                  control={control}
                  render={({ field }) => (
                    <div>
                      <label className="block text-sm mb-1">Larg. (cm)</label>
                      <input
                        type="number"
                        step="0.01"
                        {...field}
                        value={field.value ?? ""}
                        className="w-full border rounded px-3 py-2"
                        placeholder="0.00"
                      />
                    </div>
                  )}
                />
                <Controller
                  name="height_cm"
                  control={control}
                  render={({ field }) => (
                    <div>
                      <label className="block text-sm mb-1">Alt. (cm)</label>
                      <input
                        type="number"
                        step="0.01"
                        {...field}
                        value={field.value ?? ""}
                        className="w-full border rounded px-3 py-2"
                        placeholder="0.00"
                      />
                    </div>
                  )}
                />
              </div>

              <Controller
                name="active"
                control={control}
                render={({ field }) => (
                  <div className="sm:col-span-2">
                    <label className="inline-flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={!!field.value}
                        onChange={(e) => field.onChange(e.target.checked ? 1 : 0)}
                      />
                      <span className="text-sm">Ativo</span>
                    </label>
                  </div>
                )}
              />

              <div className="sm:col-span-2 flex justify-end gap-2 mt-2">
                <button
                  type="button"
                  className="border rounded px-4 py-2"
                  onClick={() => setOpen(false)}
                  disabled={saving}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-black text-white rounded px-4 py-2"
                  disabled={saving}
                >
                  {saving ? "Salvando…" : "Salvar"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
