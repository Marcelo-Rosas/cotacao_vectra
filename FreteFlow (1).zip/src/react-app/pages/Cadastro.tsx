import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/react-app/providers/AuthProvider";
import SignupForm from "@/react-app/components/SignupForm";
import { Truck } from "lucide-react";



export default function CadastroPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && user) {
      navigate('/dashboard');
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="animate-spin">
          <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl shadow-xl">
              <Truck className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">FreteFlow</h1>
          <p className="text-gray-600 mt-1">Criar nova conta</p>
        </div>

        {/* Formulário de Cadastro */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <SignupForm />
        </div>

        {/* Link para voltar */}
        <div className="text-center mt-6">
          <button
            onClick={() => navigate('/')}
            className="text-orange-600 hover:text-orange-500 font-medium"
          >
            ← Voltar para página inicial
          </button>
        </div>
      </div>
    </div>
  );
}
