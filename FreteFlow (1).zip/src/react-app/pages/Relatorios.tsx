import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import Layout from '@/react-app/components/Layout';
import { get, type APIResponse } from '@/react-app/lib/http';
import { 
  DollarSign, 
  FileText, 
  TrendingUp,
  MapPin,
  Package,
  Filter
} from 'lucide-react';
import type { Cotacao, Cashback } from '@/shared/types';

interface CashbackWithDetails extends Cashback {
  numero_cotacao?: string;
  regiao_nome?: string;
}

export default function Relatorios() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [cotacoes, setCotacoes] = useState<Cotacao[]>([]);
  const [cashback, setCashback] = useState<CashbackWithDetails[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'cashback'>('overview');
  const [dateFilter, setDateFilter] = useState('30'); // days

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login');
    }
  }, [user, isLoading, navigate]);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      setLoadingData(true);
      
      const [cotacoesResponse, cashbackResponse] = await Promise.all([
        get<APIResponse<Cotacao[]>>('/api/cotacoes'),
        get<APIResponse<CashbackWithDetails[]>>('/api/cashback')
      ]);

      setCotacoes(cotacoesResponse.data || []);
      setCashback(cashbackResponse.data || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoadingData(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  // Calculate statistics
  const stats = {
    totalCotacoes: cotacoes.length,
    cotacoesFechadas: cotacoes.filter(c => c.status === 'fechada').length,
    valorTotalFretes: cotacoes.reduce((sum, c) => sum + (c.valor_frete || 0), 0),
    cashbackTotal: cashback.reduce((sum, c) => sum + c.valor_cashback, 0),
    cashbackPendente: cashback.filter(c => c.status === 'pendente').reduce((sum, c) => sum + c.valor_cashback, 0),
    cashbackPago: cashback.filter(c => c.status === 'pago').reduce((sum, c) => sum + c.valor_cashback, 0),
  };

  // Group cashback by region
  const cashbackByRegion = cashback.reduce((acc, item) => {
    const regiao = item.regiao_nome || 'Outros';
    if (!acc[regiao]) {
      acc[regiao] = { total: 0, count: 0 };
    }
    acc[regiao].total += item.valor_cashback;
    acc[regiao].count += 1;
    return acc;
  }, {} as Record<string, { total: number; count: number }>);

  // Monthly data for charts
  const getMonthlyData = () => {
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const currentMonth = new Date().getMonth();
    
    return months.slice(0, currentMonth + 1).map((month, index) => {
      const monthCotacoes = cotacoes.filter(c => {
        const cotacaoMonth = new Date(c.created_at!).getMonth();
        return cotacaoMonth === index;
      });
      
      return {
        month,
        cotacoes: monthCotacoes.length,
        faturamento: monthCotacoes.reduce((sum, c) => sum + (c.valor_frete || 0), 0)
      };
    });
  };

  const monthlyData = getMonthlyData();

  if (isLoading || loadingData) {
    return (
      <Layout>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Relatórios</h1>
            <p className="text-gray-600 mt-2">Acompanhe suas estatísticas e cashback</p>
          </div>
          <div className="flex items-center space-x-3">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="7">Últimos 7 dias</option>
              <option value="30">Últimos 30 dias</option>
              <option value="90">Últimos 90 dias</option>
              <option value="365">Último ano</option>
            </select>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === 'overview'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Visão Geral
              </button>
              <button
                onClick={() => setActiveTab('cashback')}
                className={`py-4 px-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === 'cashback'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Cashback
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-600">Total de Cotações</p>
                        <p className="text-2xl font-bold text-blue-900">{stats.totalCotacoes}</p>
                      </div>
                      <div className="p-3 bg-blue-200 rounded-lg">
                        <FileText className="w-6 h-6 text-blue-700" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-600">Fechadas</p>
                        <p className="text-2xl font-bold text-green-900">{stats.cotacoesFechadas}</p>
                      </div>
                      <div className="p-3 bg-green-200 rounded-lg">
                        <TrendingUp className="w-6 h-6 text-green-700" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-purple-600">Valor Total</p>
                        <p className="text-2xl font-bold text-purple-900">{formatCurrency(stats.valorTotalFretes)}</p>
                      </div>
                      <div className="p-3 bg-purple-200 rounded-lg">
                        <DollarSign className="w-6 h-6 text-purple-700" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-amber-50 to-amber-100 p-6 rounded-xl border border-amber-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-amber-600">Cashback Total</p>
                        <p className="text-2xl font-bold text-amber-900">{formatCurrency(stats.cashbackTotal)}</p>
                      </div>
                      <div className="p-3 bg-amber-200 rounded-lg">
                        <DollarSign className="w-6 h-6 text-amber-700" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Charts */}
                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-xl">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Cotações por Mês</h3>
                    <div className="space-y-3">
                      {monthlyData.map((data) => (
                        <div key={data.month} className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">{data.month}</span>
                          <div className="flex items-center space-x-3">
                            <div className="flex-1 w-20 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full"
                                style={{ width: `${Math.min(100, (data.cotacoes / Math.max(...monthlyData.map(d => d.cotacoes)) * 100))}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium text-gray-900 w-8">{data.cotacoes}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-xl">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Faturamento por Mês</h3>
                    <div className="space-y-3">
                      {monthlyData.map((data) => (
                        <div key={data.month} className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">{data.month}</span>
                          <div className="flex items-center space-x-3">
                            <div className="flex-1 w-20 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-green-600 h-2 rounded-full"
                                style={{ width: `${Math.min(100, (data.faturamento / Math.max(...monthlyData.map(d => d.faturamento)) * 100))}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium text-gray-900 w-20 text-right">
                              {formatCurrency(data.faturamento)}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'cashback' && (
              <div className="space-y-6">
                {/* Cashback Summary */}
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-600">Total Acumulado</p>
                        <p className="text-2xl font-bold text-green-900">{formatCurrency(stats.cashbackTotal)}</p>
                      </div>
                      <DollarSign className="w-8 h-8 text-green-600" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-6 rounded-xl border border-yellow-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-yellow-600">Pendente</p>
                        <p className="text-2xl font-bold text-yellow-900">{formatCurrency(stats.cashbackPendente)}</p>
                      </div>
                      <DollarSign className="w-8 h-8 text-yellow-600" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-600">Pago</p>
                        <p className="text-2xl font-bold text-blue-900">{formatCurrency(stats.cashbackPago)}</p>
                      </div>
                      <DollarSign className="w-8 h-8 text-blue-600" />
                    </div>
                  </div>
                </div>

                {/* Cashback by Region */}
                <div className="bg-gray-50 p-6 rounded-xl">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Cashback por Região</h3>
                  <div className="space-y-4">
                    {Object.entries(cashbackByRegion).map(([regiao, data]) => (
                      <div key={regiao} className="flex items-center justify-between p-4 bg-white rounded-lg">
                        <div className="flex items-center space-x-3">
                          <MapPin className="w-5 h-5 text-gray-400" />
                          <div>
                            <h4 className="font-medium text-gray-900">{regiao}</h4>
                            <p className="text-sm text-gray-500">{data.count} cotações</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-gray-900">{formatCurrency(data.total)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent Cashback */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Cashback Recente</h3>
                  <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                    {cashback.length === 0 ? (
                      <div className="text-center py-8">
                        <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h4 className="text-lg font-medium text-gray-900 mb-2">Nenhum cashback ainda</h4>
                        <p className="text-gray-600">O cashback será gerado quando cotações FOB forem fechadas</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Cotação
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Região
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Percentual
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Valor
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Data
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {cashback.slice(0, 10).map((item) => (
                              <tr key={item.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {item.numero_cotacao}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {item.regiao_nome}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {(item.percentual_aplicado * 100).toFixed(1)}%
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {formatCurrency(item.valor_cashback)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                    item.status === 'pago' 
                                      ? 'bg-green-100 text-green-800' 
                                      : 'bg-yellow-100 text-yellow-800'
                                  }`}>
                                    {item.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {formatDate(item.created_at!)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
