import { useEffect } from 'react';
import { useAuth } from '@/react-app/providers/AuthProvider';
import { useNavigate, Link } from 'react-router-dom';
import { Truck, Loader2 } from 'lucide-react';
import HeaderBar from "@/react-app/components/HeaderBar";
import FeatureGrid, { type FeatureItem } from "@/react-app/components/FeatureGrid";

const features: FeatureItem[] = [
  {
    title: "Gestão de Produtos",
    desc: "Cadastre e organize seus produtos com dimensões, peso e códigos únicos.",
    icon: "box",
  },
  {
    title: "Cotações Inteligentes",
    desc: "Autopreenchimento de CEP e cálculos automáticos de frete.",
    icon: "spark",
  },
  {
    title: "Relatórios Completos",
    desc: "Acompanhe cashback, estatísticas e performance das cotações.",
    icon: "table",
  },
  {
    title: "Multi-tenant Seguro",
    desc: "Cada embarcador com área isolada e dados protegidos.",
    icon: "tenant",
  },
];

export default function Home() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && user) {
      navigate('/dashboard', { replace: true });
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="animate-spin">
          <Loader2 className="w-8 h-8 text-blue-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <HeaderBar />

      {/* HERO */}
      <section className="bg-gradient-to-b from-slate-900 to-slate-800 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center py-16 md:py-20">
          <div className="flex justify-center mb-8">
            <div className="p-4 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl shadow-xl">
              <Truck className="w-12 h-12 text-white" />
            </div>
          </div>
          
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight">
            Plataforma de Cotações <br />
            <span className="text-orange-500">para Embarcadores</span>
          </h1>

          <p className="mt-6 text-slate-200/90 md:text-lg max-w-2xl mx-auto">
            Plataforma completa para simplificar a gestão de frete entre embarcadores e a Vectra Cargo.
          </p>
          <p className="mt-3 text-slate-200/80 md:text-base max-w-2xl mx-auto">
            Gerencie sua base de produtos, facilite o envio de cotações e reduza o tempo de resposta em até 40 minutos.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/login"
              className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
            >
              Fazer Login
            </Link>
            <Link
              to="/cadastro"
              className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
            >
              Solicitar Cadastro
            </Link>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="bg-zinc-100 text-slate-900">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <div className="text-center">
            <span className="inline-block rounded-full bg-slate-900 text-white px-6 py-3 text-lg font-bold">
              Recursos Completos para sua Operação
            </span>
            <p className="mt-4 text-slate-600 max-w-2xl mx-auto">
              Tudo que você precisa para gerenciar suas cotações e produtos de forma eficiente
            </p>
          </div>

          <FeatureGrid items={features} />
        </div>
      </section>

      {/* BENEFITS */}
      <section className="bg-white">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Por que escolher o FreteFlow?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Desenvolvido especialmente para otimizar a relação entre embarcadores e transportadoras
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Rapidez</h3>
              <p className="text-gray-600">
                Reduza o tempo de cotação de horas para minutos com nosso sistema automatizado
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Precisão</h3>
              <p className="text-gray-600">
                Cálculos automáticos de peso, volume e distância para cotações mais precisas
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Cashback</h3>
              <p className="text-gray-600">
                Acompanhe e gerencie seu programa de cashback por região de destino
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl">
                <Truck className="w-8 h-8 text-white" />
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">FreteFlow</h3>
            <p className="text-gray-400">
              Sistema de gestão de fretes e cotações para embarcadores
            </p>
            <div className="mt-6 text-sm text-gray-500">
              © 2024 FreteFlow. Desenvolvido pela Vectra Cargo.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
