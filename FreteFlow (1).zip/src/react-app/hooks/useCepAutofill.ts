import { useState, useCallback } from 'react';
import { get } from '@/react-app/lib/http';

export interface CepData {
  cep: string;
  uf: string;
  cidade: string;
  bairro: string;
  logradouro: string;
  provider: 'brasilapi' | 'viacep';
}

export interface UseCepAutofillOptions {
  onSuccess?: (data: CepData) => void;
  onError?: (error: string) => void;
  debounceMs?: number;
}

export interface UseCepAutofillReturn {
  isLoading: boolean;
  error: string | null;
  data: CepData | null;
  lookupCep: (cep: string) => Promise<void>;
  reset: () => void;
}

export function useCepAutofill(options: UseCepAutofillOptions = {}): UseCepAutofillReturn {
  const {
    onSuccess,
    onError,
    debounceMs = 500
  } = options;

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<CepData | null>(null);

  const lookupCep = useCallback(async (cep: string) => {
    // Normalize CEP (remove non-digits)
    const normalizedCep = cep.replace(/\D/g, '');
    
    // Reset states
    setError(null);
    setData(null);

    // Validate CEP length
    if (normalizedCep.length !== 8) {
      if (normalizedCep.length > 0) {
        const errorMsg = 'CEP deve ter 8 dígitos';
        setError(errorMsg);
        onError?.(errorMsg);
      }
      return;
    }

    setIsLoading(true);

    try {
      console.log(`[CEP Hook] Looking up: ${normalizedCep}`);
      
      const result = await get<CepData>(`/api/cep/${normalizedCep}`);
      console.log(`[CEP Hook] Success:`, result);
      
      setData(result);
      onSuccess?.(result);
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Erro ao buscar CEP';
      console.log(`[CEP Hook] Error:`, errorMsg);
      
      setError(errorMsg);
      onError?.(errorMsg);
    } finally {
      setIsLoading(false);
    }
  }, [onSuccess, onError]);

  // Debounced lookup
  const debouncedLookup = useCallback(
    debounce(lookupCep, debounceMs),
    [lookupCep, debounceMs]
  );

  const reset = useCallback(() => {
    setIsLoading(false);
    setError(null);
    setData(null);
  }, []);

  return {
    isLoading,
    error,
    data,
    lookupCep: debouncedLookup,
    reset
  };
}

// Simple debounce function
function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): T {
  let timeout: NodeJS.Timeout;
  
  return ((...args: any[]) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  }) as T;
}
