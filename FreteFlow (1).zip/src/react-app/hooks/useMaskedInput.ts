import { useState, useCallback } from 'react';

export type MaskType = 'cnpj' | 'cpf' | 'telefone';

interface MaskConfig {
  apply: (value: string) => string;
  validate: (value: string) => boolean;
  maxLength: number;
  placeholder: string;
}

const maskConfigs: Record<MaskType, MaskConfig> = {
  cnpj: {
    apply: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers
        .replace(/^(\d{2})(\d)/, '$1.$2')
        .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
        .replace(/\.(\d{3})(\d)/, '.$1/$2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .substring(0, 18);
    },
    validate: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers.length === 14;
    },
    maxLength: 18,
    placeholder: '00.000.000/0000-00'
  },
  cpf: {
    apply: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers
        .replace(/^(\d{3})(\d)/, '$1.$2')
        .replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
        .replace(/\.(\d{3})(\d)/, '.$1-$2')
        .substring(0, 14);
    },
    validate: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers.length === 11;
    },
    maxLength: 14,
    placeholder: '000.000.000-00'
  },
  telefone: {
    apply: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers
        .replace(/^(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2')
        .substring(0, 15);
    },
    validate: (value: string) => {
      const numbers = value.replace(/\D/g, '');
      return numbers.length === 10 || numbers.length === 11;
    },
    maxLength: 15,
    placeholder: '(00) 00000-0000'
  }
};

export interface UseMaskedInputReturn {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur: () => void;
  isValid: boolean;
  rawValue: string; // valor sem máscara
  maxLength: number;
  placeholder: string;
}

export function useMaskedInput(
  initialValue: string = '',
  maskType: MaskType,
  onValueChange?: (value: string, rawValue: string, isValid: boolean) => void
): UseMaskedInputReturn {
  const [value, setValue] = useState(() => {
    return maskConfigs[maskType].apply(initialValue);
  });

  const config = maskConfigs[maskType];

  const onChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const maskedValue = config.apply(e.target.value);
    setValue(maskedValue);
    
    const rawValue = maskedValue.replace(/\D/g, '');
    const isValid = config.validate(maskedValue);
    
    onValueChange?.(maskedValue, rawValue, isValid);
  }, [config, onValueChange]);

  const onBlur = useCallback(() => {
    const rawValue = value.replace(/\D/g, '');
    const isValid = config.validate(value);
    onValueChange?.(value, rawValue, isValid);
  }, [value, config, onValueChange]);

  const rawValue = value.replace(/\D/g, '');
  const isValid = config.validate(value);

  return {
    value,
    onChange,
    onBlur,
    isValid,
    rawValue,
    maxLength: config.maxLength,
    placeholder: config.placeholder
  };
}

// Utility functions para usar diretamente
export const applyMask = (value: string, maskType: MaskType): string => {
  return maskConfigs[maskType].apply(value);
};

export const validateMask = (value: string, maskType: MaskType): boolean => {
  return maskConfigs[maskType].validate(value);
};

export const removeMask = (value: string): string => {
  return value.replace(/\D/g, '');
};
