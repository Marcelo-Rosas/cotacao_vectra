// Serviços de autenticação para o sistema OTP
export interface User {
  id: string;
  email: string;
  name?: string;
  avatar_url?: string;
  email_verified: boolean;
}

export interface Session {
  id: string;
  user_agent: string;
  ip_address: string;
  created_at: string;
  expires_at: string;
}

export const AuthService = {
  // Enviar código OTP
  async sendOTP(email: string, name?: string): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, name }),
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Verificar código OTP e fazer login
  async verifyOTP(email: string, code: string): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, code }),
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Obter usuário atual
  async getCurrentUser(): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Fazer logout
  async logout(): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Limpar todas as sessões
  async clearAllSessions(): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const response = await fetch('/api/auth/sessions', {
        method: 'DELETE',
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },
};

export const UserService = {
  // Obter dados do usuário via /api/users/me
  async getMe(): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const response = await fetch('/api/users/me', {
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Atualizar dados do usuário
  async updateMe(updates: { name?: string; avatar_url?: string }): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const response = await fetch('/api/users/me', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(updates),
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Listar sessões ativas
  async getSessions(): Promise<{ success: boolean; sessions?: Session[]; error?: string }> {
    try {
      const response = await fetch('/api/users/sessions', {
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Encerrar sessão específica
  async deleteSession(sessionId: string): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const response = await fetch(`/api/users/sessions/${sessionId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },

  // Desativar conta
  async deactivateAccount(): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const response = await fetch('/api/users/me', {
        method: 'DELETE',
        credentials: 'include',
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      return { success: false, error: 'Erro de conexão' };
    }
  },
};
