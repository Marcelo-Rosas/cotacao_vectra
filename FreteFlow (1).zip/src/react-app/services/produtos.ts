export type Produto = {
  id: string;
  sku: string;
  name: string;
  ncm?: string | null;
  unit?: string | null;
  price_cents: number;
  weight_kg?: number | null;
  length_cm?: number | null;
  width_cm?: number | null;
  height_cm?: number | null;
  active: 0 | 1;
  created_at: string;
  updated_at: string;
};

type ListResponse = {
  items: Produto[];
  page: number;
  pageSize: number;
  total: number;
};

const json = (res: Response) => res.json();

export const ProdutosAPI = {
  list: (params?: { search?: string; page?: number; pageSize?: number; active?: 0 | 1 }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.page) qs.set('page', String(params.page));
    if (params?.pageSize) qs.set('pageSize', String(params.pageSize));
    if (params?.active != null) qs.set('active', String(params.active));
    return fetch(`/api/produtos?${qs.toString()}`, { credentials: 'include' })
      .then(json)
      .then((r) => (r.success ? (r.data as ListResponse) : Promise.reject(r)));
  },
  create: (payload: Partial<Produto> & { sku: string; name: string }) =>
    fetch('/api/produtos', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).then(json),
  detail: (id: string) =>
    fetch(`/api/produtos/${id}`, { credentials: 'include' }).then(json),
  update: (id: string, patch: Partial<Produto>) =>
    fetch(`/api/produtos/${id}`, {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then(json),
  remove: (id: string, force = false) =>
    fetch(`/api/produtos/${id}?force=${force ? '1' : '0'}`, {
      method: 'DELETE',
      credentials: 'include',
    }).then(json),
};
