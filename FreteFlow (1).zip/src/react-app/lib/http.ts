// Utilitário HTTP seguro para evitar SyntaxError

export interface APIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  details?: any;
}

export async function fetchJSON<T>(input: RequestInfo, init?: RequestInit): Promise<T> {
  const res = await fetch(input, { 
    credentials: "include", 
    headers: {
      'Content-Type': 'application/json',
      ...init?.headers
    },
    ...init 
  });
  
  const ct = res.headers.get("content-type") || "";
  
  if (!ct.includes("application/json")) {
    // Para debug: mostra qual endpoint não está retornando JSON
    const text = await res.text();
    console.warn(`Expected JSON but got (${res.status}):`, text);
    throw new Error(`API responded with non-JSON (status ${res.status}): ${text.substring(0, 100)}`);
  }
  
  const body = await res.json();
  
  if (!res.ok) {
    throw new Error((body as any)?.error || `HTTP ${res.status}`);
  }
  
  return body as T;
}

// Shortcuts convenientes
export async function get<T>(url: string): Promise<T> {
  return fetchJSON<T>(url, { method: 'GET' });
}

export async function post<T>(url: string, data?: any): Promise<T> {
  return fetchJSON<T>(url, {
    method: 'POST',
    body: data ? JSON.stringify(data) : undefined,
  });
}

export async function put<T>(url: string, data?: any): Promise<T> {
  return fetchJSON<T>(url, {
    method: 'PUT',
    body: data ? JSON.stringify(data) : undefined,
  });
}

export async function patch<T>(url: string, data?: any): Promise<T> {
  return fetchJSON<T>(url, {
    method: 'PATCH',
    body: data ? JSON.stringify(data) : undefined,
  });
}

export async function del<T>(url: string): Promise<T> {
  return fetchJSON<T>(url, { method: 'DELETE' });
}
