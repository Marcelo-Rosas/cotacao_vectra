import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

type User = { id: string; email: string; role: "admin"|"embarcador"; name?: string|null; company?: string|null } | null;

type Ctx = {
  user: User;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{success: boolean; error?: string}>;
  logout: () => Promise<void>;
  fetchUser: () => Promise<void>;
  // Métodos de compatibilidade
  refresh: () => Promise<void>;
  sendOTP: (email: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  verifyOTP: (email: string, code: string, password: string) => Promise<{ success: boolean; error?: string }>;
};

const AuthCtx = createContext<Ctx | undefined>(undefined);

export const AuthProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const [user, setUser] = useState<User>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUser = useCallback(async () => {
    try {
      const res = await fetch("/api/users/me", { credentials: "include" });
      if (!res.ok) { setUser(null); return; }
      const json = await res.json();
      if (json?.success) setUser(json.data);
      else setUser(null);
    } catch { setUser(null); }
  }, []);

  useEffect(() => { (async () => { await fetchUser(); setIsLoading(false); })(); }, [fetchUser]);

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password })
      });
      const json = await res.json();
      if (res.ok && json?.success) {
        await fetchUser();
        return { success:true };
      }
      return { success:false, error: json?.error || "LOGIN_FAILED" };
    } catch {
      return { success:false, error:"NETWORK_ERROR" };
    }
  };

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method:"POST", credentials:"include" });
    } finally {
      setUser(null);
    }
  };

  // Métodos de compatibilidade para manter o código existente funcionando
  const refresh = fetchUser;
  
  const sendOTP = async (email: string, name?: string) => {
    // Para compatibilidade - redireciona para register
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password: "temp", name })
      });
      const json = await res.json();
      if (res.ok && json?.success) {
        return { success: true };
      }
      return { success: false, error: json?.error || "REGISTER_FAILED" };
    } catch {
      return { success: false, error: "NETWORK_ERROR" };
    }
  };

  const verifyOTP = async (email: string, _code: string, password: string) => {
    // Para compatibilidade - tenta login direto
    return login(email, password);
  };

  return (
    <AuthCtx.Provider value={{ user, isLoading, login, logout, fetchUser, refresh, sendOTP, verifyOTP }}>
      {children}
    </AuthCtx.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth must be used within a AuthProvider");
  return ctx;
}

// Hook de compatibilidade para componentes que usam isPending
export const useAuthCompat = () => {
  const auth = useAuth();
  return {
    ...auth,
    isPending: auth.isLoading, // Alias para compatibilidade
    isAuthenticated: !!auth.user
  };
};
