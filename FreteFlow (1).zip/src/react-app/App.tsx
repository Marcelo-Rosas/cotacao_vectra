import { Routes, Route, Navigate } from "react-router-dom";

import HomePage from "@/react-app/pages/Home";
import NewLogin from "@/react-app/pages/NewLogin";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import DashboardPage from "@/react-app/pages/Dashboard";
import CotacoesPage from "@/react-app/pages/Cotacoes";
import ProdutosPage from "@/react-app/pages/Produtos";
import ProdutosPageNew from "@/react-app/pages/ProdutosPage";
import RelatoriosPage from "@/react-app/pages/Relatorios";
import CadastroPage from "@/react-app/pages/Cadastro";
import EmbarcadoresPage from "@/react-app/pages/Embarcadores";
import DevCepPage from "@/react-app/pages/DevCep";

import ProtectedRoute from "@/react-app/components/ProtectedRoute";

export default function App() {
  return (
    <Routes>
      {/* públicas */}
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<NewLogin />} />
      <Route path="/auth/callback" element={<AuthCallbackPage />} />
      <Route path="/cadastro" element={<CadastroPage />} />
      <Route path="/dev/cep" element={<DevCepPage />} />

      {/* privadas */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/cotacoes"
        element={
          <ProtectedRoute>
            <CotacoesPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/produtos"
        element={
          <ProtectedRoute>
            <ProdutosPageNew />
          </ProtectedRoute>
        }
      />
      <Route
        path="/produtos-old"
        element={
          <ProtectedRoute>
            <ProdutosPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/relatorios"
        element={
          <ProtectedRoute>
            <RelatoriosPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/embarcadores"
        element={
          <ProtectedRoute>
            <EmbarcadoresPage />
          </ProtectedRoute>
        }
      />

      {/* fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
